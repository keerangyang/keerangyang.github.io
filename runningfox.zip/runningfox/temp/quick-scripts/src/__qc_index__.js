
require('./assets/Script/cherry');
require('./assets/Script/constant');
require('./assets/Script/game');
require('./assets/Script/gem');
require('./assets/Script/ground');
require('./assets/Script/help');
require('./assets/Script/player');
require('./assets/Script/rock');
require('./assets/Script/start');
require('./assets/Script/storage');
