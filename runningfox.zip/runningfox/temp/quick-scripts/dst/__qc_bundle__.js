
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/Script/cherry');
require('./assets/Script/constant');
require('./assets/Script/game');
require('./assets/Script/gem');
require('./assets/Script/ground');
require('./assets/Script/help');
require('./assets/Script/player');
require('./assets/Script/rock');
require('./assets/Script/start');
require('./assets/Script/storage');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/gem.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '27c32vklohIJ638+4REc2Y3', 'gem');
// Script/gem.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    getRadius: 50
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxnZW0uanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJnZXRSYWRpdXMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUNJO0FBQ0ksYUFBUUQsRUFBRSxDQUFDRSxTQURmO0FBRUlDLEVBQUFBLFVBQVUsRUFBQztBQUNQQyxJQUFBQSxTQUFTLEVBQUM7QUFESDtBQUZmLENBREoiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNjLkNsYXNzKFxyXG4gICAge1xyXG4gICAgICAgIGV4dGVuZHM6Y2MuQ29tcG9uZW50LFxyXG4gICAgICAgIHByb3BlcnRpZXM6e1xyXG4gICAgICAgICAgICBnZXRSYWRpdXM6NTAsXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbikiXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/game.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'a70ccnV0U9OnrUvG4uON0Wz', 'game');
// Script/game.js

"use strict";

var _player = _interopRequireDefault(require("player"));

var _Constant = require("Constant");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

var storage = require('storage');

cc.Class({
  "extends": cc.Component,
  properties: {
    gameReflashTime: 5,
    scoreScaleDuration: 0.2,
    rockPrefabs: {
      "default": [],
      type: [cc.Prefab]
    },
    rockNode: {
      "default": null,
      type: cc.Node
    },
    gemPrefabs: {
      "default": [],
      type: [cc.Prefab]
    },
    gemNode: {
      "default": null,
      type: cc.Node
    },
    cherryPrefabs: {
      "default": [],
      type: [cc.Prefab]
    },
    cherryNode: {
      "default": null,
      type: cc.Node
    },
    player: {
      "default": null,
      type: _player["default"]
    },
    gameOverText: {
      "default": null,
      type: cc.Label
    },
    scoreText: {
      "default": null,
      type: cc.Label
    },
    highsScoreText: {
      "default": null,
      type: cc.Label
    },
    livesScoreText: {
      "default": null,
      type: cc.Label
    }
  },
  onLoad: function onLoad() {
    this.rock = [];
    this.gem = [];
    this.cherry = [];
    this.curScore = 0;
    this.curLife = 0;
    this.gemTimer = 0;
    this.cherryTimer = 0;

    if (storage.getHighScore() > 0) {
      this.highsScoreText.string = _Constant.HIGHSCORE_TEXT + storage.getHighScore();
    }

    this.schedule(this.spawnRock, 4.5);
    this.schedule(this.spawnGem, 4.5);
    this.schedule(this.spawnCherry, 4.5);
    this.schedule(this.gameUpdate, _Constant.GROUND_MOVE_INTERVAL);
    this.scoreText.string = "" + this.curScore;
    this.livesScoreText.string = "" + this.curLife;
  },
  menuBtn: function menuBtn() {
    cc.director.loadScene('start');
  },
  spawnCherry: function spawnCherry() {
    var cherry = cc.instantiate(this.cherryPrefabs[0]);
    cherry.x = (Math.random() - 0.5) * 2 * this.node.width / 2;
    cherry.y = 0;
    this.cherryNode.addChild(cherry);
    this.cherry.push(cherry);
  },
  spawnRock: function spawnRock() {
    var rock = cc.instantiate(this.rockPrefabs[0]);
    rock.x = 400;
    rock.y = -80;
    this.rockNode.addChild(rock);
    this.rock.push(rock);
  },
  spawnGem: function spawnGem() {
    var gem = cc.instantiate(this.gemPrefabs[0]);
    gem.x = (Math.random() - 0.5) * 2 * this.node.width / 2;
    gem.y = 250;
    this.gemNode.addChild(gem);
    this.gem.push(gem);
  },
  gameUpdate: function gameUpdate(dt) {
    for (var i = 0; i < this.rock.length; i++) {
      var curNode = this.rock[i];

      if (i >= 12) {
        curNode.x += _Constant.GROUND_VX[11] - i % 10;
      } else {
        curNode.x += _Constant.GROUND_VX[i % 12];
      }

      var playerBox = this.player.node.getBoundingBox();
      var rockBox = curNode.getBoundingBox();
      var curRock = curNode.getComponent('rock');

      if (cc.Intersection.rectRect(playerBox, rockBox) && curRock.isPassed === false) {
        curRock.isPassed = true;
        this.subLife();

        if (this.curLife < 0) {
          this.onGameOver();
          return;
        }
      }

      if (curNode.x < this.player.node.x && curRock.isPassed === false) {
        curRock.isPassed = true;
        this.addScore();
      }
    }

    for (var i = 0; i < this.gem.length; i++) {
      var curGemNode = this.gem[i];
      this.gemTimer += dt;

      if (this.gemTimer > _Constant.GEMDURATION) {
        this.gem.splice(i, 1);
        this.gemNode.removeChild(curGemNode, true);
        this.gemTimer = 0;
      }

      var playerPos = this.player.node.getPosition();
      var gemPos = curGemNode.getPosition();
      var temp = playerPos.sub(gemPos);
      var dist = Math.abs(temp.mag());
      var curGem = curGemNode.getComponent('gem');

      if (dist < curGem.getRadius) {
        this.gem.splice(i, 1);
        this.gemNode.removeChild(curGemNode, true);
        this.addLife();
      }
    }

    for (var i = 0; i < this.cherry.length; i++) {
      this.player.isFly = false;
      var curCherryNode = this.cherry[i];
      this.cherryTimer += dt;

      if (this.cherryTimer > _Constant.GEMDURATION) {
        this.cherry.splice(i, 1);
        this.cherryNode.removeChild(curCherryNode, true);
        this.cherryTimer = 0;
      }

      var playerPos = this.player.node.getPosition();
      var cherryPos = curCherryNode.getPosition();
      var temp = playerPos.sub(cherryPos);
      var dist = Math.abs(temp.mag());
      var curCherry = curCherryNode.getComponent('cherry');

      if (dist < curCherry.getRadius) {
        this.cherry.splice(i, 1);
        this.cherryNode.removeChild(curCherryNode, true);
        this.player.isFly = true;
      }
    }
  },
  addScore: function addScore() {
    this.curScore++;
    this.scoreText.string = "" + this.curScore;
    var action1 = cc.scaleTo(this.scoreScaleDuration, 1.1, 0.6);
    var action2 = cc.scaleTo(this.scoreScaleDuration, 0.8, 1.2);
    var action3 = cc.scaleTo(this.scoreScaleDuration, 1, 1);
    this.scoreText.node.runAction(cc.sequence(action1, action2, action3));
  },
  addLife: function addLife() {
    this.curLife++;
    this.livesScoreText.string = "" + this.curLife;
    var action1 = cc.scaleTo(this.scoreScaleDuration, 1.1, 0.6);
    var action2 = cc.scaleTo(this.scoreScaleDuration, 0.8, 1.2);
    var action3 = cc.scaleTo(this.scoreScaleDuration, 1, 1);
    this.livesScoreText.node.runAction(cc.sequence(action1, action2, action3));
  },
  subLife: function subLife() {
    this.curLife--;
    this.livesScoreText.string = "" + this.curLife;
    var action1 = cc.scaleTo(this.scoreScaleDuration, 1.1, 0.6);
    var action2 = cc.scaleTo(this.scoreScaleDuration, 0.8, 1.2);
    var action3 = cc.scaleTo(this.scoreScaleDuration, 1, 1);
    this.livesScoreText.node.runAction(cc.sequence(action1, action2, action3));
  },
  onGameOver: function onGameOver() {
    this.gameOverText.string = _Constant.GAMEOVER_TEXT;

    if (this.curScore > storage.getHighScore()) {
      storage.setHighScore(this.curScore);
    }

    this.unscheduleAllCallbacks();
    this.schedule(function () {
      cc.director.loadScene('start');
    }, this.gameReflashTime);
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxnYW1lLmpzIl0sIm5hbWVzIjpbInN0b3JhZ2UiLCJyZXF1aXJlIiwiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJnYW1lUmVmbGFzaFRpbWUiLCJzY29yZVNjYWxlRHVyYXRpb24iLCJyb2NrUHJlZmFicyIsInR5cGUiLCJQcmVmYWIiLCJyb2NrTm9kZSIsIk5vZGUiLCJnZW1QcmVmYWJzIiwiZ2VtTm9kZSIsImNoZXJyeVByZWZhYnMiLCJjaGVycnlOb2RlIiwicGxheWVyIiwiZ2FtZU92ZXJUZXh0IiwiTGFiZWwiLCJzY29yZVRleHQiLCJoaWdoc1Njb3JlVGV4dCIsImxpdmVzU2NvcmVUZXh0Iiwib25Mb2FkIiwicm9jayIsImdlbSIsImNoZXJyeSIsImN1clNjb3JlIiwiY3VyTGlmZSIsImdlbVRpbWVyIiwiY2hlcnJ5VGltZXIiLCJnZXRIaWdoU2NvcmUiLCJzdHJpbmciLCJISUdIU0NPUkVfVEVYVCIsInNjaGVkdWxlIiwic3Bhd25Sb2NrIiwic3Bhd25HZW0iLCJzcGF3bkNoZXJyeSIsImdhbWVVcGRhdGUiLCJHUk9VTkRfTU9WRV9JTlRFUlZBTCIsIm1lbnVCdG4iLCJkaXJlY3RvciIsImxvYWRTY2VuZSIsImluc3RhbnRpYXRlIiwieCIsIk1hdGgiLCJyYW5kb20iLCJub2RlIiwid2lkdGgiLCJ5IiwiYWRkQ2hpbGQiLCJwdXNoIiwiZHQiLCJpIiwibGVuZ3RoIiwiY3VyTm9kZSIsIkdST1VORF9WWCIsInBsYXllckJveCIsImdldEJvdW5kaW5nQm94Iiwicm9ja0JveCIsImN1clJvY2siLCJnZXRDb21wb25lbnQiLCJJbnRlcnNlY3Rpb24iLCJyZWN0UmVjdCIsImlzUGFzc2VkIiwic3ViTGlmZSIsIm9uR2FtZU92ZXIiLCJhZGRTY29yZSIsImN1ckdlbU5vZGUiLCJHRU1EVVJBVElPTiIsInNwbGljZSIsInJlbW92ZUNoaWxkIiwicGxheWVyUG9zIiwiZ2V0UG9zaXRpb24iLCJnZW1Qb3MiLCJ0ZW1wIiwic3ViIiwiZGlzdCIsImFicyIsIm1hZyIsImN1ckdlbSIsImdldFJhZGl1cyIsImFkZExpZmUiLCJpc0ZseSIsImN1ckNoZXJyeU5vZGUiLCJjaGVycnlQb3MiLCJjdXJDaGVycnkiLCJhY3Rpb24xIiwic2NhbGVUbyIsImFjdGlvbjIiLCJhY3Rpb24zIiwicnVuQWN0aW9uIiwic2VxdWVuY2UiLCJHQU1FT1ZFUl9URVhUIiwic2V0SGlnaFNjb3JlIiwidW5zY2hlZHVsZUFsbENhbGxiYWNrcyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTs7QUFDQTs7OztBQUVBLElBQUlBLE9BQU8sR0FBQ0MsT0FBTyxDQUFDLFNBQUQsQ0FBbkI7O0FBQ0FDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxlQUFlLEVBQUMsQ0FEUjtBQUVSQyxJQUFBQSxrQkFBa0IsRUFBQyxHQUZYO0FBR1JDLElBQUFBLFdBQVcsRUFBRTtBQUNULGlCQUFTLEVBREE7QUFFVEMsTUFBQUEsSUFBSSxFQUFFLENBQUNQLEVBQUUsQ0FBQ1EsTUFBSjtBQUZHLEtBSEw7QUFPUkMsSUFBQUEsUUFBUSxFQUFFO0FBQ04saUJBQVMsSUFESDtBQUdORixNQUFBQSxJQUFJLEVBQUVQLEVBQUUsQ0FBQ1U7QUFISCxLQVBGO0FBWVJDLElBQUFBLFVBQVUsRUFBQztBQUNQLGlCQUFRLEVBREQ7QUFFUEosTUFBQUEsSUFBSSxFQUFDLENBQUNQLEVBQUUsQ0FBQ1EsTUFBSjtBQUZFLEtBWkg7QUFnQlJJLElBQUFBLE9BQU8sRUFBQztBQUNKLGlCQUFRLElBREo7QUFFSkwsTUFBQUEsSUFBSSxFQUFDUCxFQUFFLENBQUNVO0FBRkosS0FoQkE7QUFvQlJHLElBQUFBLGFBQWEsRUFBQztBQUNWLGlCQUFRLEVBREU7QUFFVk4sTUFBQUEsSUFBSSxFQUFDLENBQUNQLEVBQUUsQ0FBQ1EsTUFBSjtBQUZLLEtBcEJOO0FBd0JSTSxJQUFBQSxVQUFVLEVBQUM7QUFDUCxpQkFBUSxJQUREO0FBRVBQLE1BQUFBLElBQUksRUFBQ1AsRUFBRSxDQUFDVTtBQUZELEtBeEJIO0FBNEJWSyxJQUFBQSxNQUFNLEVBQUM7QUFDSCxpQkFBUSxJQURMO0FBRUhSLE1BQUFBLElBQUksRUFBQ1E7QUFGRixLQTVCRztBQWlDVkMsSUFBQUEsWUFBWSxFQUFDO0FBQ1QsaUJBQVEsSUFEQztBQUVUVCxNQUFBQSxJQUFJLEVBQUNQLEVBQUUsQ0FBQ2lCO0FBRkMsS0FqQ0g7QUFxQ1ZDLElBQUFBLFNBQVMsRUFBQztBQUNOLGlCQUFRLElBREY7QUFFTlgsTUFBQUEsSUFBSSxFQUFDUCxFQUFFLENBQUNpQjtBQUZGLEtBckNBO0FBeUNWRSxJQUFBQSxjQUFjLEVBQUM7QUFDWCxpQkFBUSxJQURHO0FBRVhaLE1BQUFBLElBQUksRUFBQ1AsRUFBRSxDQUFDaUI7QUFGRyxLQXpDTDtBQTZDVkcsSUFBQUEsY0FBYyxFQUFDO0FBQ1gsaUJBQVEsSUFERztBQUVYYixNQUFBQSxJQUFJLEVBQUNQLEVBQUUsQ0FBQ2lCO0FBRkc7QUE3Q0wsR0FIUDtBQXNEUkksRUFBQUEsTUFBTSxFQUFDLGtCQUFVO0FBR2IsU0FBS0MsSUFBTCxHQUFVLEVBQVY7QUFDQSxTQUFLQyxHQUFMLEdBQVMsRUFBVDtBQUNBLFNBQUtDLE1BQUwsR0FBWSxFQUFaO0FBQ0EsU0FBS0MsUUFBTCxHQUFjLENBQWQ7QUFDQSxTQUFLQyxPQUFMLEdBQWEsQ0FBYjtBQUNBLFNBQUtDLFFBQUwsR0FBYyxDQUFkO0FBQ0EsU0FBS0MsV0FBTCxHQUFpQixDQUFqQjs7QUFDQSxRQUFHOUIsT0FBTyxDQUFDK0IsWUFBUixLQUF1QixDQUExQixFQUE0QjtBQUN4QixXQUFLVixjQUFMLENBQW9CVyxNQUFwQixHQUEyQkMsMkJBQWVqQyxPQUFPLENBQUMrQixZQUFSLEVBQTFDO0FBQ0g7O0FBQ0YsU0FBS0csUUFBTCxDQUFjLEtBQUtDLFNBQW5CLEVBQTZCLEdBQTdCO0FBQ0EsU0FBS0QsUUFBTCxDQUFjLEtBQUtFLFFBQW5CLEVBQTRCLEdBQTVCO0FBQ0EsU0FBS0YsUUFBTCxDQUFjLEtBQUtHLFdBQW5CLEVBQStCLEdBQS9CO0FBQ0EsU0FBS0gsUUFBTCxDQUFjLEtBQUtJLFVBQW5CLEVBQThCQyw4QkFBOUI7QUFDQSxTQUFLbkIsU0FBTCxDQUFlWSxNQUFmLEdBQXNCLEtBQUcsS0FBS0wsUUFBOUI7QUFDQSxTQUFLTCxjQUFMLENBQW9CVSxNQUFwQixHQUEyQixLQUFHLEtBQUtKLE9BQW5DO0FBQ0YsR0F6RU87QUEwRUxZLEVBQUFBLE9BQU8sRUFBQyxtQkFBVTtBQUNsQnRDLElBQUFBLEVBQUUsQ0FBQ3VDLFFBQUgsQ0FBWUMsU0FBWixDQUFzQixPQUF0QjtBQUNDLEdBNUVJO0FBNkVMTCxFQUFBQSxXQUFXLEVBQUMsdUJBQVU7QUFDbEIsUUFBSVgsTUFBTSxHQUFFeEIsRUFBRSxDQUFDeUMsV0FBSCxDQUFlLEtBQUs1QixhQUFMLENBQW1CLENBQW5CLENBQWYsQ0FBWjtBQUNBVyxJQUFBQSxNQUFNLENBQUNrQixDQUFQLEdBQVMsQ0FBQ0MsSUFBSSxDQUFDQyxNQUFMLEtBQWdCLEdBQWpCLElBQXdCLENBQXhCLEdBQTBCLEtBQUtDLElBQUwsQ0FBVUMsS0FBcEMsR0FBMEMsQ0FBbkQ7QUFDQXRCLElBQUFBLE1BQU0sQ0FBQ3VCLENBQVAsR0FBUyxDQUFUO0FBQ0EsU0FBS2pDLFVBQUwsQ0FBZ0JrQyxRQUFoQixDQUF5QnhCLE1BQXpCO0FBQ0EsU0FBS0EsTUFBTCxDQUFZeUIsSUFBWixDQUFpQnpCLE1BQWpCO0FBQ0gsR0FuRkk7QUFvRkxTLEVBQUFBLFNBQVMsRUFBQyxxQkFBVTtBQUNwQixRQUFJWCxJQUFJLEdBQUN0QixFQUFFLENBQUN5QyxXQUFILENBQWUsS0FBS25DLFdBQUwsQ0FBaUIsQ0FBakIsQ0FBZixDQUFUO0FBQ0FnQixJQUFBQSxJQUFJLENBQUNvQixDQUFMLEdBQU8sR0FBUDtBQUNBcEIsSUFBQUEsSUFBSSxDQUFDeUIsQ0FBTCxHQUFPLENBQUMsRUFBUjtBQUNBLFNBQUt0QyxRQUFMLENBQWN1QyxRQUFkLENBQXVCMUIsSUFBdkI7QUFDQSxTQUFLQSxJQUFMLENBQVUyQixJQUFWLENBQWUzQixJQUFmO0FBQ0MsR0ExRkk7QUEyRkxZLEVBQUFBLFFBQVEsRUFBQyxvQkFBVTtBQUNmLFFBQUlYLEdBQUcsR0FBQ3ZCLEVBQUUsQ0FBQ3lDLFdBQUgsQ0FBZSxLQUFLOUIsVUFBTCxDQUFnQixDQUFoQixDQUFmLENBQVI7QUFDQVksSUFBQUEsR0FBRyxDQUFDbUIsQ0FBSixHQUFNLENBQUNDLElBQUksQ0FBQ0MsTUFBTCxLQUFnQixHQUFqQixJQUF3QixDQUF4QixHQUEwQixLQUFLQyxJQUFMLENBQVVDLEtBQXBDLEdBQTBDLENBQWhEO0FBQ0F2QixJQUFBQSxHQUFHLENBQUN3QixDQUFKLEdBQU0sR0FBTjtBQUNBLFNBQUtuQyxPQUFMLENBQWFvQyxRQUFiLENBQXNCekIsR0FBdEI7QUFDQSxTQUFLQSxHQUFMLENBQVMwQixJQUFULENBQWMxQixHQUFkO0FBQ0gsR0FqR0k7QUFrR05hLEVBQUFBLFVBQVUsRUFBQyxvQkFBU2MsRUFBVCxFQUFZO0FBQ3JCLFNBQUksSUFBSUMsQ0FBQyxHQUFDLENBQVYsRUFBWUEsQ0FBQyxHQUFDLEtBQUs3QixJQUFMLENBQVU4QixNQUF4QixFQUErQkQsQ0FBQyxFQUFoQyxFQUFtQztBQUMvQixVQUFJRSxPQUFPLEdBQUMsS0FBSy9CLElBQUwsQ0FBVTZCLENBQVYsQ0FBWjs7QUFDQSxVQUFHQSxDQUFDLElBQUUsRUFBTixFQUFTO0FBQ0xFLFFBQUFBLE9BQU8sQ0FBQ1gsQ0FBUixJQUFXWSxvQkFBVSxFQUFWLElBQWNILENBQUMsR0FBQyxFQUEzQjtBQUNILE9BRkQsTUFHSTtBQUNERSxRQUFBQSxPQUFPLENBQUNYLENBQVIsSUFBV1ksb0JBQVVILENBQUMsR0FBQyxFQUFaLENBQVg7QUFDRjs7QUFDRCxVQUFJSSxTQUFTLEdBQUMsS0FBS3hDLE1BQUwsQ0FBWThCLElBQVosQ0FBaUJXLGNBQWpCLEVBQWQ7QUFDQSxVQUFJQyxPQUFPLEdBQUNKLE9BQU8sQ0FBQ0csY0FBUixFQUFaO0FBQ0EsVUFBSUUsT0FBTyxHQUFDTCxPQUFPLENBQUNNLFlBQVIsQ0FBcUIsTUFBckIsQ0FBWjs7QUFDQSxVQUFHM0QsRUFBRSxDQUFDNEQsWUFBSCxDQUFnQkMsUUFBaEIsQ0FBeUJOLFNBQXpCLEVBQW1DRSxPQUFuQyxLQUE2Q0MsT0FBTyxDQUFDSSxRQUFSLEtBQW1CLEtBQW5FLEVBQXlFO0FBQ3JFSixRQUFBQSxPQUFPLENBQUNJLFFBQVIsR0FBaUIsSUFBakI7QUFDQSxhQUFLQyxPQUFMOztBQUNBLFlBQUcsS0FBS3JDLE9BQUwsR0FBYSxDQUFoQixFQUFrQjtBQUNmLGVBQUtzQyxVQUFMO0FBQ0E7QUFDRjtBQUNKOztBQUVELFVBQUdYLE9BQU8sQ0FBQ1gsQ0FBUixHQUFVLEtBQUszQixNQUFMLENBQVk4QixJQUFaLENBQWlCSCxDQUEzQixJQUE4QmdCLE9BQU8sQ0FBQ0ksUUFBUixLQUFtQixLQUFwRCxFQUEwRDtBQUN0REosUUFBQUEsT0FBTyxDQUFDSSxRQUFSLEdBQWlCLElBQWpCO0FBQ0EsYUFBS0csUUFBTDtBQUVIO0FBQ0o7O0FBQ0QsU0FBSSxJQUFJZCxDQUFDLEdBQUMsQ0FBVixFQUFZQSxDQUFDLEdBQUMsS0FBSzVCLEdBQUwsQ0FBUzZCLE1BQXZCLEVBQThCRCxDQUFDLEVBQS9CLEVBQWtDO0FBRS9CLFVBQUllLFVBQVUsR0FBQyxLQUFLM0MsR0FBTCxDQUFTNEIsQ0FBVCxDQUFmO0FBQ0MsV0FBS3hCLFFBQUwsSUFBZXVCLEVBQWY7O0FBQ0EsVUFBRyxLQUFLdkIsUUFBTCxHQUFjd0MscUJBQWpCLEVBQTZCO0FBQ3pCLGFBQUs1QyxHQUFMLENBQVM2QyxNQUFULENBQWdCakIsQ0FBaEIsRUFBa0IsQ0FBbEI7QUFDQSxhQUFLdkMsT0FBTCxDQUFheUQsV0FBYixDQUF5QkgsVUFBekIsRUFBb0MsSUFBcEM7QUFDQSxhQUFLdkMsUUFBTCxHQUFjLENBQWQ7QUFDSDs7QUFDRCxVQUFJMkMsU0FBUyxHQUFDLEtBQUt2RCxNQUFMLENBQVk4QixJQUFaLENBQWlCMEIsV0FBakIsRUFBZDtBQUNBLFVBQUlDLE1BQU0sR0FBQ04sVUFBVSxDQUFDSyxXQUFYLEVBQVg7QUFDQSxVQUFJRSxJQUFJLEdBQUNILFNBQVMsQ0FBQ0ksR0FBVixDQUFjRixNQUFkLENBQVQ7QUFDQSxVQUFJRyxJQUFJLEdBQUNoQyxJQUFJLENBQUNpQyxHQUFMLENBQVNILElBQUksQ0FBQ0ksR0FBTCxFQUFULENBQVQ7QUFDQSxVQUFJQyxNQUFNLEdBQUNaLFVBQVUsQ0FBQ1AsWUFBWCxDQUF3QixLQUF4QixDQUFYOztBQUNELFVBQUdnQixJQUFJLEdBQUNHLE1BQU0sQ0FBQ0MsU0FBZixFQUF5QjtBQUNyQixhQUFLeEQsR0FBTCxDQUFTNkMsTUFBVCxDQUFnQmpCLENBQWhCLEVBQWtCLENBQWxCO0FBQ0EsYUFBS3ZDLE9BQUwsQ0FBYXlELFdBQWIsQ0FBeUJILFVBQXpCLEVBQW9DLElBQXBDO0FBQ0EsYUFBS2MsT0FBTDtBQUVIO0FBRUg7O0FBQ0QsU0FBSSxJQUFJN0IsQ0FBQyxHQUFDLENBQVYsRUFBWUEsQ0FBQyxHQUFDLEtBQUszQixNQUFMLENBQVk0QixNQUExQixFQUFpQ0QsQ0FBQyxFQUFsQyxFQUFxQztBQUNsQyxXQUFLcEMsTUFBTCxDQUFZa0UsS0FBWixHQUFrQixLQUFsQjtBQUNBLFVBQUlDLGFBQWEsR0FBQyxLQUFLMUQsTUFBTCxDQUFZMkIsQ0FBWixDQUFsQjtBQUNDLFdBQUt2QixXQUFMLElBQWtCc0IsRUFBbEI7O0FBQ0EsVUFBRyxLQUFLdEIsV0FBTCxHQUFpQnVDLHFCQUFwQixFQUFnQztBQUM1QixhQUFLM0MsTUFBTCxDQUFZNEMsTUFBWixDQUFtQmpCLENBQW5CLEVBQXFCLENBQXJCO0FBQ0EsYUFBS3JDLFVBQUwsQ0FBZ0J1RCxXQUFoQixDQUE0QmEsYUFBNUIsRUFBMEMsSUFBMUM7QUFDQSxhQUFLdEQsV0FBTCxHQUFpQixDQUFqQjtBQUNIOztBQUNELFVBQUkwQyxTQUFTLEdBQUMsS0FBS3ZELE1BQUwsQ0FBWThCLElBQVosQ0FBaUIwQixXQUFqQixFQUFkO0FBQ0EsVUFBSVksU0FBUyxHQUFDRCxhQUFhLENBQUNYLFdBQWQsRUFBZDtBQUNBLFVBQUlFLElBQUksR0FBQ0gsU0FBUyxDQUFDSSxHQUFWLENBQWNTLFNBQWQsQ0FBVDtBQUNBLFVBQUlSLElBQUksR0FBQ2hDLElBQUksQ0FBQ2lDLEdBQUwsQ0FBU0gsSUFBSSxDQUFDSSxHQUFMLEVBQVQsQ0FBVDtBQUNBLFVBQUlPLFNBQVMsR0FBQ0YsYUFBYSxDQUFDdkIsWUFBZCxDQUEyQixRQUEzQixDQUFkOztBQUNELFVBQUdnQixJQUFJLEdBQUNTLFNBQVMsQ0FBQ0wsU0FBbEIsRUFBNEI7QUFDeEIsYUFBS3ZELE1BQUwsQ0FBWTRDLE1BQVosQ0FBbUJqQixDQUFuQixFQUFxQixDQUFyQjtBQUNBLGFBQUtyQyxVQUFMLENBQWdCdUQsV0FBaEIsQ0FBNEJhLGFBQTVCLEVBQTBDLElBQTFDO0FBQ0EsYUFBS25FLE1BQUwsQ0FBWWtFLEtBQVosR0FBa0IsSUFBbEI7QUFDSDtBQUVIO0FBQ0YsR0F4S0s7QUF5S05oQixFQUFBQSxRQUFRLEVBQUMsb0JBQVU7QUFDZixTQUFLeEMsUUFBTDtBQUNBLFNBQUtQLFNBQUwsQ0FBZVksTUFBZixHQUFzQixLQUFHLEtBQUtMLFFBQTlCO0FBQ0EsUUFBSTRELE9BQU8sR0FBQ3JGLEVBQUUsQ0FBQ3NGLE9BQUgsQ0FBVyxLQUFLakYsa0JBQWhCLEVBQW1DLEdBQW5DLEVBQXVDLEdBQXZDLENBQVo7QUFDQSxRQUFJa0YsT0FBTyxHQUFDdkYsRUFBRSxDQUFDc0YsT0FBSCxDQUFXLEtBQUtqRixrQkFBaEIsRUFBbUMsR0FBbkMsRUFBdUMsR0FBdkMsQ0FBWjtBQUNBLFFBQUltRixPQUFPLEdBQUN4RixFQUFFLENBQUNzRixPQUFILENBQVcsS0FBS2pGLGtCQUFoQixFQUFtQyxDQUFuQyxFQUFxQyxDQUFyQyxDQUFaO0FBQ0EsU0FBS2EsU0FBTCxDQUFlMkIsSUFBZixDQUFvQjRDLFNBQXBCLENBQThCekYsRUFBRSxDQUFDMEYsUUFBSCxDQUFZTCxPQUFaLEVBQW9CRSxPQUFwQixFQUE0QkMsT0FBNUIsQ0FBOUI7QUFDSCxHQWhMSztBQWlMTlIsRUFBQUEsT0FBTyxFQUFDLG1CQUFVO0FBQ2QsU0FBS3RELE9BQUw7QUFDQSxTQUFLTixjQUFMLENBQW9CVSxNQUFwQixHQUEyQixLQUFHLEtBQUtKLE9BQW5DO0FBQ0EsUUFBSTJELE9BQU8sR0FBQ3JGLEVBQUUsQ0FBQ3NGLE9BQUgsQ0FBVyxLQUFLakYsa0JBQWhCLEVBQW1DLEdBQW5DLEVBQXVDLEdBQXZDLENBQVo7QUFDQSxRQUFJa0YsT0FBTyxHQUFDdkYsRUFBRSxDQUFDc0YsT0FBSCxDQUFXLEtBQUtqRixrQkFBaEIsRUFBbUMsR0FBbkMsRUFBdUMsR0FBdkMsQ0FBWjtBQUNBLFFBQUltRixPQUFPLEdBQUN4RixFQUFFLENBQUNzRixPQUFILENBQVcsS0FBS2pGLGtCQUFoQixFQUFtQyxDQUFuQyxFQUFxQyxDQUFyQyxDQUFaO0FBQ0EsU0FBS2UsY0FBTCxDQUFvQnlCLElBQXBCLENBQXlCNEMsU0FBekIsQ0FBbUN6RixFQUFFLENBQUMwRixRQUFILENBQVlMLE9BQVosRUFBb0JFLE9BQXBCLEVBQTRCQyxPQUE1QixDQUFuQztBQUNELEdBeExHO0FBeUxMekIsRUFBQUEsT0FBTyxFQUFDLG1CQUFVO0FBQ2QsU0FBS3JDLE9BQUw7QUFDQSxTQUFLTixjQUFMLENBQW9CVSxNQUFwQixHQUEyQixLQUFHLEtBQUtKLE9BQW5DO0FBQ0EsUUFBSTJELE9BQU8sR0FBQ3JGLEVBQUUsQ0FBQ3NGLE9BQUgsQ0FBVyxLQUFLakYsa0JBQWhCLEVBQW1DLEdBQW5DLEVBQXVDLEdBQXZDLENBQVo7QUFDQSxRQUFJa0YsT0FBTyxHQUFDdkYsRUFBRSxDQUFDc0YsT0FBSCxDQUFXLEtBQUtqRixrQkFBaEIsRUFBbUMsR0FBbkMsRUFBdUMsR0FBdkMsQ0FBWjtBQUNBLFFBQUltRixPQUFPLEdBQUN4RixFQUFFLENBQUNzRixPQUFILENBQVcsS0FBS2pGLGtCQUFoQixFQUFtQyxDQUFuQyxFQUFxQyxDQUFyQyxDQUFaO0FBQ0EsU0FBS2UsY0FBTCxDQUFvQnlCLElBQXBCLENBQXlCNEMsU0FBekIsQ0FBbUN6RixFQUFFLENBQUMwRixRQUFILENBQVlMLE9BQVosRUFBb0JFLE9BQXBCLEVBQTRCQyxPQUE1QixDQUFuQztBQUNILEdBaE1JO0FBaU1OeEIsRUFBQUEsVUFBVSxFQUFDLHNCQUFVO0FBQ2pCLFNBQUtoRCxZQUFMLENBQWtCYyxNQUFsQixHQUF5QjZELHVCQUF6Qjs7QUFDQSxRQUFHLEtBQUtsRSxRQUFMLEdBQWMzQixPQUFPLENBQUMrQixZQUFSLEVBQWpCLEVBQXdDO0FBQ3BDL0IsTUFBQUEsT0FBTyxDQUFDOEYsWUFBUixDQUFxQixLQUFLbkUsUUFBMUI7QUFDSDs7QUFDQSxTQUFLb0Usc0JBQUw7QUFDQSxTQUFLN0QsUUFBTCxDQUFjLFlBQVc7QUFDckJoQyxNQUFBQSxFQUFFLENBQUN1QyxRQUFILENBQVlDLFNBQVosQ0FBc0IsT0FBdEI7QUFDSCxLQUZELEVBRUcsS0FBS3BDLGVBRlI7QUFHSjtBQTFNSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgcGxheWVyIGZyb20gJ3BsYXllcic7XHJcbmltcG9ydCB7IEdST1VORF9NT1ZFX0lOVEVSVkFMLEdBTUVPVkVSX1RFWFQsR1JPVU5EX1ZYLEdFTURVUkFUSU9OLEhJR0hTQ09SRV9URVhULGlzUHJlc3NlZCB9IGZyb20gJ0NvbnN0YW50JzsgXHJcblxyXG52YXIgc3RvcmFnZT1yZXF1aXJlKCdzdG9yYWdlJyk7XHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuIFxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIGdhbWVSZWZsYXNoVGltZTo1LFxyXG4gICAgICAgIHNjb3JlU2NhbGVEdXJhdGlvbjowLjIsXHJcbiAgICAgICAgcm9ja1ByZWZhYnM6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogW10sXHJcbiAgICAgICAgICAgIHR5cGU6IFtjYy5QcmVmYWJdXHJcbiAgICAgICAgfSxcclxuICAgICAgICByb2NrTm9kZTogeyBcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGVcclxuICAgICAgICB9LFxyXG4gICAgICAgIGdlbVByZWZhYnM6e1xyXG4gICAgICAgICAgICBkZWZhdWx0OltdLFxyXG4gICAgICAgICAgICB0eXBlOltjYy5QcmVmYWJdXHJcbiAgICAgICAgfSxcclxuICAgICAgICBnZW1Ob2RlOntcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0eXBlOmNjLk5vZGVcclxuICAgICAgICB9LFxyXG4gICAgICAgIGNoZXJyeVByZWZhYnM6e1xyXG4gICAgICAgICAgICBkZWZhdWx0OltdLFxyXG4gICAgICAgICAgICB0eXBlOltjYy5QcmVmYWJdXHJcbiAgICAgICAgfSxcclxuICAgICAgICBjaGVycnlOb2RlOntcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0eXBlOmNjLk5vZGVcclxuICAgICAgICB9LFxyXG4gICAgICBwbGF5ZXI6e1xyXG4gICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgdHlwZTpwbGF5ZXJcclxuICAgICAgfSxcclxuICAgICBcclxuICAgICAgZ2FtZU92ZXJUZXh0OntcclxuICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgIHR5cGU6Y2MuTGFiZWxcclxuICAgICAgfSxcclxuICAgICAgc2NvcmVUZXh0OntcclxuICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgIHR5cGU6Y2MuTGFiZWxcclxuICAgICAgfSxcclxuICAgICAgaGlnaHNTY29yZVRleHQ6e1xyXG4gICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgdHlwZTpjYy5MYWJlbFxyXG4gICAgICB9LFxyXG4gICAgICBsaXZlc1Njb3JlVGV4dDp7XHJcbiAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICB0eXBlOmNjLkxhYmVsXHJcbiAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gb25Mb2FkOmZ1bmN0aW9uKCl7XHJcblxyXG4gIFxyXG4gICAgIHRoaXMucm9jaz1bXTtcclxuICAgICB0aGlzLmdlbT1bXTtcclxuICAgICB0aGlzLmNoZXJyeT1bXTtcclxuICAgICB0aGlzLmN1clNjb3JlPTA7XHJcbiAgICAgdGhpcy5jdXJMaWZlPTA7XHJcbiAgICAgdGhpcy5nZW1UaW1lcj0wO1xyXG4gICAgIHRoaXMuY2hlcnJ5VGltZXI9MDtcclxuICAgICBpZihzdG9yYWdlLmdldEhpZ2hTY29yZSgpPjApe1xyXG4gICAgICAgICB0aGlzLmhpZ2hzU2NvcmVUZXh0LnN0cmluZz1ISUdIU0NPUkVfVEVYVCtzdG9yYWdlLmdldEhpZ2hTY29yZSgpO1xyXG4gICAgIH1cclxuICAgIHRoaXMuc2NoZWR1bGUodGhpcy5zcGF3blJvY2ssNC41KTtcclxuICAgIHRoaXMuc2NoZWR1bGUodGhpcy5zcGF3bkdlbSw0LjUpO1xyXG4gICAgdGhpcy5zY2hlZHVsZSh0aGlzLnNwYXduQ2hlcnJ5LDQuNSk7XHJcbiAgICB0aGlzLnNjaGVkdWxlKHRoaXMuZ2FtZVVwZGF0ZSxHUk9VTkRfTU9WRV9JTlRFUlZBTCk7XHJcbiAgICB0aGlzLnNjb3JlVGV4dC5zdHJpbmc9XCJcIit0aGlzLmN1clNjb3JlO1xyXG4gICAgdGhpcy5saXZlc1Njb3JlVGV4dC5zdHJpbmc9XCJcIit0aGlzLmN1ckxpZmU7XHJcbiB9LFxyXG4gICAgbWVudUJ0bjpmdW5jdGlvbigpe1xyXG4gICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKCdzdGFydCcpO1xyXG4gICAgfSxcclxuICAgIHNwYXduQ2hlcnJ5OmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIGNoZXJyeSA9Y2MuaW5zdGFudGlhdGUodGhpcy5jaGVycnlQcmVmYWJzWzBdKTtcclxuICAgICAgICBjaGVycnkueD0oTWF0aC5yYW5kb20oKSAtIDAuNSkgKiAyKnRoaXMubm9kZS53aWR0aC8yO1xyXG4gICAgICAgIGNoZXJyeS55PTA7XHJcbiAgICAgICAgdGhpcy5jaGVycnlOb2RlLmFkZENoaWxkKGNoZXJyeSk7XHJcbiAgICAgICAgdGhpcy5jaGVycnkucHVzaChjaGVycnkpO1xyXG4gICAgfSxcclxuICAgIHNwYXduUm9jazpmdW5jdGlvbigpe1xyXG4gICAgdmFyIHJvY2s9Y2MuaW5zdGFudGlhdGUodGhpcy5yb2NrUHJlZmFic1swXSk7XHJcbiAgICByb2NrLng9NDAwO1xyXG4gICAgcm9jay55PS04MDtcclxuICAgIHRoaXMucm9ja05vZGUuYWRkQ2hpbGQocm9jayk7XHJcbiAgICB0aGlzLnJvY2sucHVzaChyb2NrKTtcclxuICAgIH0sXHJcbiAgICBzcGF3bkdlbTpmdW5jdGlvbigpe1xyXG4gICAgICAgIHZhciBnZW09Y2MuaW5zdGFudGlhdGUodGhpcy5nZW1QcmVmYWJzWzBdKTtcclxuICAgICAgICBnZW0ueD0oTWF0aC5yYW5kb20oKSAtIDAuNSkgKiAyKnRoaXMubm9kZS53aWR0aC8yO1xyXG4gICAgICAgIGdlbS55PTI1MDtcclxuICAgICAgICB0aGlzLmdlbU5vZGUuYWRkQ2hpbGQoZ2VtKTtcclxuICAgICAgICB0aGlzLmdlbS5wdXNoKGdlbSk7XHJcbiAgICB9LFxyXG4gICBnYW1lVXBkYXRlOmZ1bmN0aW9uKGR0KXtcclxuICAgICBmb3IodmFyIGk9MDtpPHRoaXMucm9jay5sZW5ndGg7aSsrKXtcclxuICAgICAgICAgdmFyIGN1ck5vZGU9dGhpcy5yb2NrW2ldO1xyXG4gICAgICAgICBpZihpPj0xMil7XHJcbiAgICAgICAgICAgICBjdXJOb2RlLngrPUdST1VORF9WWFsxMV0taSUxMDtcclxuICAgICAgICAgfVxyXG4gICAgICAgICBlbHNle1xyXG4gICAgICAgICAgICBjdXJOb2RlLngrPUdST1VORF9WWFtpJTEyXTtcclxuICAgICAgICAgfVxyXG4gICAgICAgICB2YXIgcGxheWVyQm94PXRoaXMucGxheWVyLm5vZGUuZ2V0Qm91bmRpbmdCb3goKTtcclxuICAgICAgICAgdmFyIHJvY2tCb3g9Y3VyTm9kZS5nZXRCb3VuZGluZ0JveCgpO1xyXG4gICAgICAgICB2YXIgY3VyUm9jaz1jdXJOb2RlLmdldENvbXBvbmVudCgncm9jaycpO1xyXG4gICAgICAgICBpZihjYy5JbnRlcnNlY3Rpb24ucmVjdFJlY3QocGxheWVyQm94LHJvY2tCb3gpJiZjdXJSb2NrLmlzUGFzc2VkPT09ZmFsc2Upe1xyXG4gICAgICAgICAgICAgY3VyUm9jay5pc1Bhc3NlZD10cnVlO1xyXG4gICAgICAgICAgICAgdGhpcy5zdWJMaWZlKCk7XHJcbiAgICAgICAgICAgICBpZih0aGlzLmN1ckxpZmU8MCl7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm9uR2FtZU92ZXIoKTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgIH1cclxuICAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgICBpZihjdXJOb2RlLng8dGhpcy5wbGF5ZXIubm9kZS54JiZjdXJSb2NrLmlzUGFzc2VkPT09ZmFsc2Upe1xyXG4gICAgICAgICAgICAgY3VyUm9jay5pc1Bhc3NlZD10cnVlO1xyXG4gICAgICAgICAgICAgdGhpcy5hZGRTY29yZSgpO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgfVxyXG4gICAgIH1cclxuICAgICBmb3IodmFyIGk9MDtpPHRoaXMuZ2VtLmxlbmd0aDtpKyspe1xyXG4gICAgICAgXHJcbiAgICAgICAgdmFyIGN1ckdlbU5vZGU9dGhpcy5nZW1baV07XHJcbiAgICAgICAgIHRoaXMuZ2VtVGltZXIrPWR0O1xyXG4gICAgICAgICBpZih0aGlzLmdlbVRpbWVyPkdFTURVUkFUSU9OKXtcclxuICAgICAgICAgICAgIHRoaXMuZ2VtLnNwbGljZShpLDEpO1xyXG4gICAgICAgICAgICAgdGhpcy5nZW1Ob2RlLnJlbW92ZUNoaWxkKGN1ckdlbU5vZGUsdHJ1ZSk7XHJcbiAgICAgICAgICAgICB0aGlzLmdlbVRpbWVyPTA7XHJcbiAgICAgICAgIH1cclxuICAgICAgICAgdmFyIHBsYXllclBvcz10aGlzLnBsYXllci5ub2RlLmdldFBvc2l0aW9uKCk7XHJcbiAgICAgICAgIHZhciBnZW1Qb3M9Y3VyR2VtTm9kZS5nZXRQb3NpdGlvbigpO1xyXG4gICAgICAgICB2YXIgdGVtcD1wbGF5ZXJQb3Muc3ViKGdlbVBvcyk7XHJcbiAgICAgICAgIHZhciBkaXN0PU1hdGguYWJzKHRlbXAubWFnKCkpO1xyXG4gICAgICAgICB2YXIgY3VyR2VtPWN1ckdlbU5vZGUuZ2V0Q29tcG9uZW50KCdnZW0nKTtcclxuICAgICAgICBpZihkaXN0PGN1ckdlbS5nZXRSYWRpdXMpe1xyXG4gICAgICAgICAgICB0aGlzLmdlbS5zcGxpY2UoaSwxKTtcclxuICAgICAgICAgICAgdGhpcy5nZW1Ob2RlLnJlbW92ZUNoaWxkKGN1ckdlbU5vZGUsdHJ1ZSk7XHJcbiAgICAgICAgICAgIHRoaXMuYWRkTGlmZSgpO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICB9XHJcbiAgICAgICBcclxuICAgICB9XHJcbiAgICAgZm9yKHZhciBpPTA7aTx0aGlzLmNoZXJyeS5sZW5ndGg7aSsrKXtcclxuICAgICAgICB0aGlzLnBsYXllci5pc0ZseT1mYWxzZTsgXHJcbiAgICAgICAgdmFyIGN1ckNoZXJyeU5vZGU9dGhpcy5jaGVycnlbaV07XHJcbiAgICAgICAgIHRoaXMuY2hlcnJ5VGltZXIrPWR0O1xyXG4gICAgICAgICBpZih0aGlzLmNoZXJyeVRpbWVyPkdFTURVUkFUSU9OKXtcclxuICAgICAgICAgICAgIHRoaXMuY2hlcnJ5LnNwbGljZShpLDEpO1xyXG4gICAgICAgICAgICAgdGhpcy5jaGVycnlOb2RlLnJlbW92ZUNoaWxkKGN1ckNoZXJyeU5vZGUsdHJ1ZSk7XHJcbiAgICAgICAgICAgICB0aGlzLmNoZXJyeVRpbWVyPTA7XHJcbiAgICAgICAgIH1cclxuICAgICAgICAgdmFyIHBsYXllclBvcz10aGlzLnBsYXllci5ub2RlLmdldFBvc2l0aW9uKCk7XHJcbiAgICAgICAgIHZhciBjaGVycnlQb3M9Y3VyQ2hlcnJ5Tm9kZS5nZXRQb3NpdGlvbigpO1xyXG4gICAgICAgICB2YXIgdGVtcD1wbGF5ZXJQb3Muc3ViKGNoZXJyeVBvcyk7XHJcbiAgICAgICAgIHZhciBkaXN0PU1hdGguYWJzKHRlbXAubWFnKCkpO1xyXG4gICAgICAgICB2YXIgY3VyQ2hlcnJ5PWN1ckNoZXJyeU5vZGUuZ2V0Q29tcG9uZW50KCdjaGVycnknKTtcclxuICAgICAgICBpZihkaXN0PGN1ckNoZXJyeS5nZXRSYWRpdXMpe1xyXG4gICAgICAgICAgICB0aGlzLmNoZXJyeS5zcGxpY2UoaSwxKTtcclxuICAgICAgICAgICAgdGhpcy5jaGVycnlOb2RlLnJlbW92ZUNoaWxkKGN1ckNoZXJyeU5vZGUsdHJ1ZSk7XHJcbiAgICAgICAgICAgIHRoaXMucGxheWVyLmlzRmx5PXRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgXHJcbiAgICAgfVxyXG4gICB9LFxyXG4gICBhZGRTY29yZTpmdW5jdGlvbigpe1xyXG4gICAgICAgdGhpcy5jdXJTY29yZSsrO1xyXG4gICAgICAgdGhpcy5zY29yZVRleHQuc3RyaW5nPVwiXCIrdGhpcy5jdXJTY29yZTtcclxuICAgICAgIHZhciBhY3Rpb24xPWNjLnNjYWxlVG8odGhpcy5zY29yZVNjYWxlRHVyYXRpb24sMS4xLDAuNik7XHJcbiAgICAgICB2YXIgYWN0aW9uMj1jYy5zY2FsZVRvKHRoaXMuc2NvcmVTY2FsZUR1cmF0aW9uLDAuOCwxLjIpO1xyXG4gICAgICAgdmFyIGFjdGlvbjM9Y2Muc2NhbGVUbyh0aGlzLnNjb3JlU2NhbGVEdXJhdGlvbiwxLDEpO1xyXG4gICAgICAgdGhpcy5zY29yZVRleHQubm9kZS5ydW5BY3Rpb24oY2Muc2VxdWVuY2UoYWN0aW9uMSxhY3Rpb24yLGFjdGlvbjMpKTtcclxuICAgfSxcclxuICAgYWRkTGlmZTpmdW5jdGlvbigpe1xyXG4gICAgICAgdGhpcy5jdXJMaWZlKys7XHJcbiAgICAgICB0aGlzLmxpdmVzU2NvcmVUZXh0LnN0cmluZz1cIlwiK3RoaXMuY3VyTGlmZTtcclxuICAgICAgIHZhciBhY3Rpb24xPWNjLnNjYWxlVG8odGhpcy5zY29yZVNjYWxlRHVyYXRpb24sMS4xLDAuNik7XHJcbiAgICAgICB2YXIgYWN0aW9uMj1jYy5zY2FsZVRvKHRoaXMuc2NvcmVTY2FsZUR1cmF0aW9uLDAuOCwxLjIpO1xyXG4gICAgICAgdmFyIGFjdGlvbjM9Y2Muc2NhbGVUbyh0aGlzLnNjb3JlU2NhbGVEdXJhdGlvbiwxLDEpO1xyXG4gICAgICAgdGhpcy5saXZlc1Njb3JlVGV4dC5ub2RlLnJ1bkFjdGlvbihjYy5zZXF1ZW5jZShhY3Rpb24xLGFjdGlvbjIsYWN0aW9uMykpO1xyXG4gICAgIH0sXHJcbiAgICBzdWJMaWZlOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdGhpcy5jdXJMaWZlLS07XHJcbiAgICAgICAgdGhpcy5saXZlc1Njb3JlVGV4dC5zdHJpbmc9XCJcIit0aGlzLmN1ckxpZmU7XHJcbiAgICAgICAgdmFyIGFjdGlvbjE9Y2Muc2NhbGVUbyh0aGlzLnNjb3JlU2NhbGVEdXJhdGlvbiwxLjEsMC42KTtcclxuICAgICAgICB2YXIgYWN0aW9uMj1jYy5zY2FsZVRvKHRoaXMuc2NvcmVTY2FsZUR1cmF0aW9uLDAuOCwxLjIpO1xyXG4gICAgICAgIHZhciBhY3Rpb24zPWNjLnNjYWxlVG8odGhpcy5zY29yZVNjYWxlRHVyYXRpb24sMSwxKTtcclxuICAgICAgICB0aGlzLmxpdmVzU2NvcmVUZXh0Lm5vZGUucnVuQWN0aW9uKGNjLnNlcXVlbmNlKGFjdGlvbjEsYWN0aW9uMixhY3Rpb24zKSk7XHJcbiAgICB9LFxyXG4gICBvbkdhbWVPdmVyOmZ1bmN0aW9uKCl7XHJcbiAgICAgICB0aGlzLmdhbWVPdmVyVGV4dC5zdHJpbmc9R0FNRU9WRVJfVEVYVDtcclxuICAgICAgIGlmKHRoaXMuY3VyU2NvcmU+c3RvcmFnZS5nZXRIaWdoU2NvcmUoKSl7XHJcbiAgICAgICAgICAgc3RvcmFnZS5zZXRIaWdoU2NvcmUodGhpcy5jdXJTY29yZSk7XHJcbiAgICAgICB9XHJcbiAgICAgICAgdGhpcy51bnNjaGVkdWxlQWxsQ2FsbGJhY2tzKCk7XHJcbiAgICAgICAgdGhpcy5zY2hlZHVsZShmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKCdzdGFydCcpO1xyXG4gICAgICAgIH0sIHRoaXMuZ2FtZVJlZmxhc2hUaW1lKTtcclxuICAgfVxyXG59KTsiXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/start.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '70b81/DQRFKPpV1hbZ91sa6', 'start');
// Script/start.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {},
  start: function start() {},
  onLoad: function onLoad() {},
  startBtn: function startBtn() {
    cc.director.loadScene('game');
  },
  helpBtn: function helpBtn() {
    cc.director.loadScene('help');
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxzdGFydC5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsInN0YXJ0Iiwib25Mb2FkIiwic3RhcnRCdG4iLCJkaXJlY3RvciIsImxvYWRTY2VuZSIsImhlbHBCdG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRSxFQUhQO0FBT0xDLEVBQUFBLEtBUEssbUJBT0ksQ0FFUixDQVRJO0FBVUxDLEVBQUFBLE1BQU0sRUFBQyxrQkFBVSxDQUVwQixDQVpRO0FBYU5DLEVBQUFBLFFBQVEsRUFBQyxvQkFBVTtBQUNsQk4sSUFBQUEsRUFBRSxDQUFDTyxRQUFILENBQVlDLFNBQVosQ0FBc0IsTUFBdEI7QUFDQSxHQWZLO0FBZ0JOQyxFQUFBQSxPQUFPLEVBQUMsbUJBQVU7QUFDZFQsSUFBQUEsRUFBRSxDQUFDTyxRQUFILENBQVlDLFNBQVosQ0FBc0IsTUFBdEI7QUFDSDtBQWxCSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG4gICAgb25Mb2FkOmZ1bmN0aW9uKCl7XHJcblxyXG59LFxyXG4gICBzdGFydEJ0bjpmdW5jdGlvbigpe1xyXG4gICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKCdnYW1lJyk7XHJcbiAgIH0sXHJcbiAgIGhlbHBCdG46ZnVuY3Rpb24oKXtcclxuICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZSgnaGVscCcpO1xyXG4gICB9XHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/ground.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b594dHWKURNF42Y0SDCJYRY', 'ground');
// Script/ground.js

"use strict";

var _Constant = require("Constant");

var Background = cc.Class({
  "extends": cc.Component,
  properties: {
    // 地板节点数组
    groundNode: {
      "default": [],
      type: [cc.Node]
    },
    // 地板图片对象
    groundImg: {
      "default": null,
      type: cc.Sprite
    }
  },
  // use this for initialization
  onLoad: function onLoad() {
    // 获取屏幕尺寸
    this._size = cc.winSize; // 获取地板图片的宽度

    this._width = this.groundImg.spriteFrame.getRect().width; // 启动“地板移动控制”计时器

    this.schedule(this.onGroundMove, _Constant.GROUND_MOVE_INTERVAL);
  },
  onGroundMove: function onGroundMove() {
    this.groundNode[0].x += _Constant.GROUND_VX[7];
    this.groundNode[1].x += _Constant.GROUND_VX[7];

    if (this.groundNode[0].x <= -962) {
      this.groundNode[0].x = 962;
    }

    if (this.groundNode[1].x <= -962) {
      this.groundNode[1].x = 962;
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxncm91bmQuanMiXSwibmFtZXMiOlsiQmFja2dyb3VuZCIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiZ3JvdW5kTm9kZSIsInR5cGUiLCJOb2RlIiwiZ3JvdW5kSW1nIiwiU3ByaXRlIiwib25Mb2FkIiwiX3NpemUiLCJ3aW5TaXplIiwiX3dpZHRoIiwic3ByaXRlRnJhbWUiLCJnZXRSZWN0Iiwid2lkdGgiLCJzY2hlZHVsZSIsIm9uR3JvdW5kTW92ZSIsIkdST1VORF9NT1ZFX0lOVEVSVkFMIiwieCIsIkdST1VORF9WWCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQTs7QUFFQSxJQUFJQSxVQUFVLEdBQUdDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ3RCLGFBQVNELEVBQUUsQ0FBQ0UsU0FEVTtBQUd0QkMsRUFBQUEsVUFBVSxFQUFFO0FBQ1I7QUFDQUMsSUFBQUEsVUFBVSxFQUFFO0FBQ1IsaUJBQVMsRUFERDtBQUVSQyxNQUFBQSxJQUFJLEVBQUUsQ0FBQ0wsRUFBRSxDQUFDTSxJQUFKO0FBRkUsS0FGSjtBQU1SO0FBQ0FDLElBQUFBLFNBQVMsRUFBRTtBQUNQLGlCQUFTLElBREY7QUFFUEYsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNRO0FBRkY7QUFQSCxHQUhVO0FBZ0J0QjtBQUNBQyxFQUFBQSxNQUFNLEVBQUUsa0JBQVk7QUFDaEI7QUFDQSxTQUFLQyxLQUFMLEdBQWFWLEVBQUUsQ0FBQ1csT0FBaEIsQ0FGZ0IsQ0FHaEI7O0FBQ0EsU0FBS0MsTUFBTCxHQUFjLEtBQUtMLFNBQUwsQ0FBZU0sV0FBZixDQUEyQkMsT0FBM0IsR0FBcUNDLEtBQW5ELENBSmdCLENBS2hCOztBQUNBLFNBQUtDLFFBQUwsQ0FBYyxLQUFLQyxZQUFuQixFQUFpQ0MsOEJBQWpDO0FBQ0gsR0F4QnFCO0FBMEJ0QkQsRUFBQUEsWUFBWSxFQUFFLHdCQUFXO0FBRWpCLFNBQUtiLFVBQUwsQ0FBZ0IsQ0FBaEIsRUFBbUJlLENBQW5CLElBQXdCQyxvQkFBVSxDQUFWLENBQXhCO0FBQ0EsU0FBS2hCLFVBQUwsQ0FBZ0IsQ0FBaEIsRUFBbUJlLENBQW5CLElBQXdCQyxvQkFBVSxDQUFWLENBQXhCOztBQUNBLFFBQUksS0FBS2hCLFVBQUwsQ0FBZ0IsQ0FBaEIsRUFBbUJlLENBQW5CLElBQXVCLENBQUMsR0FBNUIsRUFBaUM7QUFDN0IsV0FBS2YsVUFBTCxDQUFnQixDQUFoQixFQUFtQmUsQ0FBbkIsR0FBdUIsR0FBdkI7QUFDSDs7QUFDRCxRQUFJLEtBQUtmLFVBQUwsQ0FBZ0IsQ0FBaEIsRUFBbUJlLENBQW5CLElBQXlCLENBQUMsR0FBOUIsRUFBbUM7QUFDL0IsV0FBS2YsVUFBTCxDQUFnQixDQUFoQixFQUFtQmUsQ0FBbkIsR0FBdUIsR0FBdkI7QUFDSDtBQUdSO0FBdENxQixDQUFULENBQWpCIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJcclxuaW1wb3J0IHsgR1JPVU5EX01PVkVfSU5URVJWQUwsIEdST1VORF9WWCB9IGZyb20gJ0NvbnN0YW50JztcclxuIFxyXG52YXIgQmFja2dyb3VuZCA9IGNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuIFxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIC8vIOWcsOadv+iKgueCueaVsOe7hFxyXG4gICAgICAgIGdyb3VuZE5vZGU6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogW10sXHJcbiAgICAgICAgICAgIHR5cGU6IFtjYy5Ob2RlXVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgLy8g5Zyw5p2/5Zu+54mH5a+56LGhXHJcbiAgICAgICAgZ3JvdW5kSW1nOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLlNwcml0ZVxyXG4gICAgICAgIH0sXHJcbiAgICB9LFxyXG4gXHJcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIC8vIOiOt+WPluWxj+W5leWwuuWvuFxyXG4gICAgICAgIHRoaXMuX3NpemUgPSBjYy53aW5TaXplO1xyXG4gICAgICAgIC8vIOiOt+WPluWcsOadv+WbvueJh+eahOWuveW6plxyXG4gICAgICAgIHRoaXMuX3dpZHRoID0gdGhpcy5ncm91bmRJbWcuc3ByaXRlRnJhbWUuZ2V0UmVjdCgpLndpZHRoO1xyXG4gICAgICAgIC8vIOWQr+WKqOKAnOWcsOadv+enu+WKqOaOp+WItuKAneiuoeaXtuWZqFxyXG4gICAgICAgIHRoaXMuc2NoZWR1bGUodGhpcy5vbkdyb3VuZE1vdmUsIEdST1VORF9NT1ZFX0lOVEVSVkFMKTtcclxuICAgIH0sXHJcbiBcclxuICAgIG9uR3JvdW5kTW92ZTogZnVuY3Rpb24oKSB7XHJcbiAgICAgICBcclxuICAgICAgICAgICAgdGhpcy5ncm91bmROb2RlWzBdLnggKz0gR1JPVU5EX1ZYWzddO1xyXG4gICAgICAgICAgICB0aGlzLmdyb3VuZE5vZGVbMV0ueCArPSBHUk9VTkRfVlhbN107XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmdyb3VuZE5vZGVbMF0ueCA8PS05NjIpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuZ3JvdW5kTm9kZVswXS54ID0gOTYyIDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAodGhpcy5ncm91bmROb2RlWzFdLnggIDw9IC05NjIpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuZ3JvdW5kTm9kZVsxXS54ID0gOTYyIDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICBcclxuICAgIH0sXHJcbn0pOyJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/rock.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '95c1123kHVEbq8T7H9jqbtA', 'rock');
// Script/rock.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    // 小鸟通过管道与否的标志位
    isPassed: false
  },
  // use this for initialization
  onLoad: function onLoad() {},
  init: function init(type) {
    // 设置管道的类型（上或下）
    this.type = type;
  } // called every frame, uncomment this function to activate update callback
  // update: function (dt) {
  // },

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxyb2NrLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiaXNQYXNzZWQiLCJvbkxvYWQiLCJpbml0IiwidHlwZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1I7QUFDQUMsSUFBQUEsUUFBUSxFQUFFO0FBRkYsR0FIUDtBQVFMO0FBQ0FDLEVBQUFBLE1BQU0sRUFBRSxrQkFBWSxDQUVuQixDQVhJO0FBYUxDLEVBQUFBLElBQUksRUFBRSxjQUFVQyxJQUFWLEVBQWdCO0FBQ2xCO0FBQ0EsU0FBS0EsSUFBTCxHQUFZQSxJQUFaO0FBQ0gsR0FoQkksQ0FrQkw7QUFDQTtBQUVBOztBQXJCSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcbiBcclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICAvLyDlsI/puJ/pgJrov4fnrqHpgZPkuI7lkKbnmoTmoIflv5fkvY1cclxuICAgICAgICBpc1Bhc3NlZDogZmFsc2UsXHJcbiAgICB9LFxyXG4gXHJcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG4gXHJcbiAgICB9LFxyXG4gXHJcbiAgICBpbml0OiBmdW5jdGlvbiAodHlwZSkge1xyXG4gICAgICAgIC8vIOiuvue9rueuoemBk+eahOexu+Wei++8iOS4iuaIluS4i++8iVxyXG4gICAgICAgIHRoaXMudHlwZSA9IHR5cGU7XHJcbiAgICB9XHJcbiBcclxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXHJcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xyXG4gXHJcbiAgICAvLyB9LFxyXG59KTsiXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/help.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'c2840TkJnVG+bE7Zp843Jx0', 'help');
// Script/help.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  onload: function onload() {},
  onHelpBtn: function onHelpBtn() {
    cc.director.loadScene('start');
    isPressed = false;
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxoZWxwLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwib25sb2FkIiwib25IZWxwQnRuIiwiZGlyZWN0b3IiLCJsb2FkU2NlbmUiLCJpc1ByZXNzZWQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRSxFQUhQO0FBTUxDLEVBQUFBLE1BQU0sRUFBQyxrQkFBVSxDQUVoQixDQVJJO0FBU0xDLEVBQUFBLFNBQVMsRUFBQyxxQkFBWTtBQUNsQkwsSUFBQUEsRUFBRSxDQUFDTSxRQUFILENBQVlDLFNBQVosQ0FBc0IsT0FBdEI7QUFDQUMsSUFBQUEsU0FBUyxHQUFDLEtBQVY7QUFDSDtBQVpJLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICBcclxuICAgIH0sXHJcbiAgICBvbmxvYWQ6ZnVuY3Rpb24oKXtcclxuICAgICAgICBcclxuICAgIH0sXHJcbiAgICBvbkhlbHBCdG46ZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZSgnc3RhcnQnKTtcclxuICAgICAgICBpc1ByZXNzZWQ9ZmFsc2U7XHJcbiAgICB9LFxyXG5cclxuICAgXHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/player.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '280c3rsZJJKnZ9RqbALVwtK', 'player');
// Script/player.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    jumpHeight: 200,
    jumpDuration: 0.35,
    flyHeight: 250,
    flyDuration: 2,
    xSpeed: 350,
    AnimName: 'fox'
  },
  onLoad: function onLoad() {
    this.getComponent(cc.Animation).play(this.AnimName); // 初始化键盘输入监听

    cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
    cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, this.onKeyUp, this);
  },
  start: function start() {},
  update: function update(dt) {
    //根据当前速度方向每帧更新速度
    if (this.accLeft) {
      this.node.x -= this.xSpeed * dt;
    } else if (this.accRight) {
      this.node.x += this.xSpeed * dt;
    }
  },
  onDestroy: function onDestroy() {
    // 取消键盘输入监听
    cc.systemEvent.off(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
    cc.systemEvent.off(cc.SystemEvent.EventType.KEY_UP, this.onKeyUp, this);
  },
  //跳跃功能，在跳跃期间暂停跳跃功能
  jumpAction: function jumpAction() {
    var jumpUp = cc.moveBy(this.jumpDuration, cc.v2(0, this.jumpHeight)).easing(cc.easeCubicActionOut());
    var jumpDown = cc.moveBy(this.jumpDuration, cc.v2(0, -this.jumpHeight)).easing(cc.easeCubicActionIn());
    var setJump = cc.callFunc(function () {
      this.isJump = false;
    }, this, this);
    return cc.sequence(jumpUp, jumpDown, setJump);
  },
  flyAction: function flyAction() {
    var flyUp = cc.moveBy(this.flyDuration, cc.v2(0, this.flyHeight)).easing(cc.easeCubicActionOut());
    var flyDown = cc.moveBy(this.flyDuration, cc.v2(0, -this.flyHeight)).easing(cc.easeCubicActionIn());
    var setFly = cc.callFunc(function () {
      this.isFly = false;
    }, this, this);
    return cc.sequence(flyUp, flyDown, setFly);
  },
  onKeyDown: function onKeyDown(event) {
    switch (event.keyCode) {
      case cc.macro.KEY.a:
        console.log(this.node.x);
        this.accLeft = true;
        break;

      case cc.macro.KEY.d:
        this.accRight = true;
        break;

      case cc.macro.KEY.w:
        if (!this.isJump) {
          this.isJump = true;
          this.node.runAction(this.jumpAction());
        }

        break;

      case cc.macro.KEY.q:
        if (this.isFly) {
          this.isFly = true;
          this.node.runAction(this.flyAction());
        }

        break;
    }
  },
  onKeyUp: function onKeyUp(event) {
    switch (event.keyCode) {
      case cc.macro.KEY.a:
        this.accLeft = false;
        break;

      case cc.macro.KEY.d:
        this.accRight = false;
        break;
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxwbGF5ZXIuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJqdW1wSGVpZ2h0IiwianVtcER1cmF0aW9uIiwiZmx5SGVpZ2h0IiwiZmx5RHVyYXRpb24iLCJ4U3BlZWQiLCJBbmltTmFtZSIsIm9uTG9hZCIsImdldENvbXBvbmVudCIsIkFuaW1hdGlvbiIsInBsYXkiLCJzeXN0ZW1FdmVudCIsIm9uIiwiU3lzdGVtRXZlbnQiLCJFdmVudFR5cGUiLCJLRVlfRE9XTiIsIm9uS2V5RG93biIsIktFWV9VUCIsIm9uS2V5VXAiLCJzdGFydCIsInVwZGF0ZSIsImR0IiwiYWNjTGVmdCIsIm5vZGUiLCJ4IiwiYWNjUmlnaHQiLCJvbkRlc3Ryb3kiLCJvZmYiLCJqdW1wQWN0aW9uIiwianVtcFVwIiwibW92ZUJ5IiwidjIiLCJlYXNpbmciLCJlYXNlQ3ViaWNBY3Rpb25PdXQiLCJqdW1wRG93biIsImVhc2VDdWJpY0FjdGlvbkluIiwic2V0SnVtcCIsImNhbGxGdW5jIiwiaXNKdW1wIiwic2VxdWVuY2UiLCJmbHlBY3Rpb24iLCJmbHlVcCIsImZseURvd24iLCJzZXRGbHkiLCJpc0ZseSIsImV2ZW50Iiwia2V5Q29kZSIsIm1hY3JvIiwiS0VZIiwiYSIsImNvbnNvbGUiLCJsb2ciLCJkIiwidyIsInJ1bkFjdGlvbiIsInEiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxVQUFVLEVBQUUsR0FESjtBQUVSQyxJQUFBQSxZQUFZLEVBQUUsSUFGTjtBQUdSQyxJQUFBQSxTQUFTLEVBQUMsR0FIRjtBQUlSQyxJQUFBQSxXQUFXLEVBQUMsQ0FKSjtBQUtSQyxJQUFBQSxNQUFNLEVBQUcsR0FMRDtBQU1SQyxJQUFBQSxRQUFRLEVBQUU7QUFORixHQUhQO0FBWUxDLEVBQUFBLE1BWkssb0JBWUs7QUFDTixTQUFLQyxZQUFMLENBQWtCWCxFQUFFLENBQUNZLFNBQXJCLEVBQWdDQyxJQUFoQyxDQUFxQyxLQUFLSixRQUExQyxFQURNLENBRVo7O0FBQ01ULElBQUFBLEVBQUUsQ0FBQ2MsV0FBSCxDQUFlQyxFQUFmLENBQWtCZixFQUFFLENBQUNnQixXQUFILENBQWVDLFNBQWYsQ0FBeUJDLFFBQTNDLEVBQXFELEtBQUtDLFNBQTFELEVBQXFFLElBQXJFO0FBQ0FuQixJQUFBQSxFQUFFLENBQUNjLFdBQUgsQ0FBZUMsRUFBZixDQUFrQmYsRUFBRSxDQUFDZ0IsV0FBSCxDQUFlQyxTQUFmLENBQXlCRyxNQUEzQyxFQUFtRCxLQUFLQyxPQUF4RCxFQUFpRSxJQUFqRTtBQUNKLEdBakJLO0FBbUJQQyxFQUFBQSxLQW5CTyxtQkFtQkUsQ0FDUixDQXBCTTtBQXNCUEMsRUFBQUEsTUFBTSxFQUFFLGdCQUFVQyxFQUFWLEVBQWM7QUFDaEI7QUFDQSxRQUFJLEtBQUtDLE9BQVQsRUFBa0I7QUFDZCxXQUFLQyxJQUFMLENBQVVDLENBQVYsSUFBZSxLQUFLbkIsTUFBTCxHQUFjZ0IsRUFBN0I7QUFDSCxLQUZELE1BRU8sSUFBSSxLQUFLSSxRQUFULEVBQW1CO0FBQ3RCLFdBQUtGLElBQUwsQ0FBVUMsQ0FBVixJQUFlLEtBQUtuQixNQUFMLEdBQWNnQixFQUE3QjtBQUNIO0FBRUosR0E5Qkk7QUFnQ05LLEVBQUFBLFNBaENNLHVCQWdDTztBQUNSO0FBQ0E3QixJQUFBQSxFQUFFLENBQUNjLFdBQUgsQ0FBZWdCLEdBQWYsQ0FBbUI5QixFQUFFLENBQUNnQixXQUFILENBQWVDLFNBQWYsQ0FBeUJDLFFBQTVDLEVBQXNELEtBQUtDLFNBQTNELEVBQXNFLElBQXRFO0FBQ0FuQixJQUFBQSxFQUFFLENBQUNjLFdBQUgsQ0FBZWdCLEdBQWYsQ0FBbUI5QixFQUFFLENBQUNnQixXQUFILENBQWVDLFNBQWYsQ0FBeUJHLE1BQTVDLEVBQW9ELEtBQUtDLE9BQXpELEVBQWtFLElBQWxFO0FBQ0gsR0FwQ0k7QUFzQ1I7QUFDR1UsRUFBQUEsVUF2Q0ssd0JBdUNRO0FBQ1gsUUFBSUMsTUFBTSxHQUFHaEMsRUFBRSxDQUFDaUMsTUFBSCxDQUFVLEtBQUs1QixZQUFmLEVBQTZCTCxFQUFFLENBQUNrQyxFQUFILENBQU0sQ0FBTixFQUFRLEtBQUs5QixVQUFiLENBQTdCLEVBQXVEK0IsTUFBdkQsQ0FBOERuQyxFQUFFLENBQUNvQyxrQkFBSCxFQUE5RCxDQUFiO0FBQ0EsUUFBSUMsUUFBUSxHQUFHckMsRUFBRSxDQUFDaUMsTUFBSCxDQUFVLEtBQUs1QixZQUFmLEVBQTZCTCxFQUFFLENBQUNrQyxFQUFILENBQU0sQ0FBTixFQUFTLENBQUMsS0FBSzlCLFVBQWYsQ0FBN0IsRUFBeUQrQixNQUF6RCxDQUFnRW5DLEVBQUUsQ0FBQ3NDLGlCQUFILEVBQWhFLENBQWY7QUFDQSxRQUFJQyxPQUFPLEdBQUN2QyxFQUFFLENBQUN3QyxRQUFILENBQVksWUFBVTtBQUFDLFdBQUtDLE1BQUwsR0FBWSxLQUFaO0FBQWtCLEtBQXpDLEVBQTBDLElBQTFDLEVBQStDLElBQS9DLENBQVo7QUFDQSxXQUFPekMsRUFBRSxDQUFDMEMsUUFBSCxDQUFZVixNQUFaLEVBQW1CSyxRQUFuQixFQUE0QkUsT0FBNUIsQ0FBUDtBQUNELEdBNUNJO0FBNkNMSSxFQUFBQSxTQTdDSyx1QkE2Q087QUFDUixRQUFJQyxLQUFLLEdBQUc1QyxFQUFFLENBQUNpQyxNQUFILENBQVUsS0FBSzFCLFdBQWYsRUFBNEJQLEVBQUUsQ0FBQ2tDLEVBQUgsQ0FBTSxDQUFOLEVBQVEsS0FBSzVCLFNBQWIsQ0FBNUIsRUFBcUQ2QixNQUFyRCxDQUE0RG5DLEVBQUUsQ0FBQ29DLGtCQUFILEVBQTVELENBQVo7QUFDQSxRQUFJUyxPQUFPLEdBQUc3QyxFQUFFLENBQUNpQyxNQUFILENBQVUsS0FBSzFCLFdBQWYsRUFBNEJQLEVBQUUsQ0FBQ2tDLEVBQUgsQ0FBTSxDQUFOLEVBQVMsQ0FBQyxLQUFLNUIsU0FBZixDQUE1QixFQUF1RDZCLE1BQXZELENBQThEbkMsRUFBRSxDQUFDc0MsaUJBQUgsRUFBOUQsQ0FBZDtBQUNBLFFBQUlRLE1BQU0sR0FBQzlDLEVBQUUsQ0FBQ3dDLFFBQUgsQ0FBWSxZQUFVO0FBQUMsV0FBS08sS0FBTCxHQUFXLEtBQVg7QUFBaUIsS0FBeEMsRUFBeUMsSUFBekMsRUFBOEMsSUFBOUMsQ0FBWDtBQUNBLFdBQU8vQyxFQUFFLENBQUMwQyxRQUFILENBQVlFLEtBQVosRUFBa0JDLE9BQWxCLEVBQTBCQyxNQUExQixDQUFQO0FBQ0QsR0FsREU7QUFtREwzQixFQUFBQSxTQW5ESyxxQkFtRE02QixLQW5ETixFQW1EYTtBQUNkLFlBQU9BLEtBQUssQ0FBQ0MsT0FBYjtBQUNJLFdBQUtqRCxFQUFFLENBQUNrRCxLQUFILENBQVNDLEdBQVQsQ0FBYUMsQ0FBbEI7QUFDQUMsUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksS0FBSzVCLElBQUwsQ0FBVUMsQ0FBdEI7QUFDSSxhQUFLRixPQUFMLEdBQWUsSUFBZjtBQUNBOztBQUNKLFdBQUt6QixFQUFFLENBQUNrRCxLQUFILENBQVNDLEdBQVQsQ0FBYUksQ0FBbEI7QUFDSSxhQUFLM0IsUUFBTCxHQUFnQixJQUFoQjtBQUNBOztBQUNKLFdBQUs1QixFQUFFLENBQUNrRCxLQUFILENBQVNDLEdBQVQsQ0FBYUssQ0FBbEI7QUFDRSxZQUFHLENBQUMsS0FBS2YsTUFBVCxFQUFnQjtBQUNkLGVBQUtBLE1BQUwsR0FBYyxJQUFkO0FBQ0EsZUFBS2YsSUFBTCxDQUFVK0IsU0FBVixDQUFvQixLQUFLMUIsVUFBTCxFQUFwQjtBQUNEOztBQUNEOztBQUNBLFdBQUsvQixFQUFFLENBQUNrRCxLQUFILENBQVNDLEdBQVQsQ0FBYU8sQ0FBbEI7QUFDSSxZQUFHLEtBQUtYLEtBQVIsRUFBYztBQUNWLGVBQUtBLEtBQUwsR0FBVyxJQUFYO0FBQ0EsZUFBS3JCLElBQUwsQ0FBVStCLFNBQVYsQ0FBb0IsS0FBS2QsU0FBTCxFQUFwQjtBQUNIOztBQUNIO0FBbkJSO0FBcUJILEdBekVJO0FBMkVSdEIsRUFBQUEsT0EzRVEsbUJBMkVDMkIsS0EzRUQsRUEyRVE7QUFDVCxZQUFPQSxLQUFLLENBQUNDLE9BQWI7QUFDSSxXQUFLakQsRUFBRSxDQUFDa0QsS0FBSCxDQUFTQyxHQUFULENBQWFDLENBQWxCO0FBQ0ksYUFBSzNCLE9BQUwsR0FBZSxLQUFmO0FBQ0E7O0FBQ0osV0FBS3pCLEVBQUUsQ0FBQ2tELEtBQUgsQ0FBU0MsR0FBVCxDQUFhSSxDQUFsQjtBQUNJLGFBQUszQixRQUFMLEdBQWdCLEtBQWhCO0FBQ0E7QUFOUjtBQVFIO0FBcEZJLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAganVtcEhlaWdodDogMjAwLFxyXG4gICAgICAgIGp1bXBEdXJhdGlvbjogMC4zNSxcclxuICAgICAgICBmbHlIZWlnaHQ6MjUwLFxyXG4gICAgICAgIGZseUR1cmF0aW9uOjIsXHJcbiAgICAgICAgeFNwZWVkIDogMzUwLFxyXG4gICAgICAgIEFuaW1OYW1lOiAnZm94JyxcclxuICAgIH0sXHJcbiAgICBcclxuICAgIG9uTG9hZCAoKSB7XHJcbiAgICAgICAgdGhpcy5nZXRDb21wb25lbnQoY2MuQW5pbWF0aW9uKS5wbGF5KHRoaXMuQW5pbU5hbWUpO1xyXG5cdFx0Ly8g5Yid5aeL5YyW6ZSu55uY6L6T5YWl55uR5ZCsXHJcbiAgICAgICAgY2Muc3lzdGVtRXZlbnQub24oY2MuU3lzdGVtRXZlbnQuRXZlbnRUeXBlLktFWV9ET1dOLCB0aGlzLm9uS2V5RG93biwgdGhpcyk7XHJcbiAgICAgICAgY2Muc3lzdGVtRXZlbnQub24oY2MuU3lzdGVtRXZlbnQuRXZlbnRUeXBlLktFWV9VUCwgdGhpcy5vbktleVVwLCB0aGlzKTtcclxuICAgfSxcclxuXHJcbiAgc3RhcnQgKCkge1xyXG4gIH0sXHJcblxyXG4gIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XHJcbiAgICAgICAgLy/moLnmja7lvZPliY3pgJ/luqbmlrnlkJHmr4/luKfmm7TmlrDpgJ/luqZcclxuICAgICAgICBpZiAodGhpcy5hY2NMZWZ0KSB7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS54IC09IHRoaXMueFNwZWVkICogZHQ7XHJcbiAgICAgICAgfSBlbHNlIGlmICh0aGlzLmFjY1JpZ2h0KSB7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS54ICs9IHRoaXMueFNwZWVkICogZHQ7XHJcbiAgICAgICAgfVxyXG5cclxuICAgIH0sXHJcblxyXG5cdCAgb25EZXN0cm95ICgpIHtcclxuICAgICAgICAvLyDlj5bmtojplK7nm5jovpPlhaXnm5HlkKxcclxuICAgICAgICBjYy5zeXN0ZW1FdmVudC5vZmYoY2MuU3lzdGVtRXZlbnQuRXZlbnRUeXBlLktFWV9ET1dOLCB0aGlzLm9uS2V5RG93biwgdGhpcyk7XHJcbiAgICAgICAgY2Muc3lzdGVtRXZlbnQub2ZmKGNjLlN5c3RlbUV2ZW50LkV2ZW50VHlwZS5LRVlfVVAsIHRoaXMub25LZXlVcCwgdGhpcyk7XHJcbiAgICB9LFxyXG5cclxuXHQvL+i3s+i3g+WKn+iDve+8jOWcqOi3s+i3g+acn+mXtOaaguWBnOi3s+i3g+WKn+iDvVxyXG4gICAganVtcEFjdGlvbiAoKXtcclxuICAgICAgdmFyIGp1bXBVcCA9IGNjLm1vdmVCeSh0aGlzLmp1bXBEdXJhdGlvbiwgY2MudjIoMCx0aGlzLmp1bXBIZWlnaHQpKS5lYXNpbmcoY2MuZWFzZUN1YmljQWN0aW9uT3V0KCkpXHJcbiAgICAgIHZhciBqdW1wRG93biA9IGNjLm1vdmVCeSh0aGlzLmp1bXBEdXJhdGlvbiwgY2MudjIoMCwgLXRoaXMuanVtcEhlaWdodCkpLmVhc2luZyhjYy5lYXNlQ3ViaWNBY3Rpb25JbigpKTtcclxuICAgICAgdmFyIHNldEp1bXA9Y2MuY2FsbEZ1bmMoZnVuY3Rpb24oKXt0aGlzLmlzSnVtcD1mYWxzZX0sdGhpcyx0aGlzKTtcclxuICAgICAgcmV0dXJuIGNjLnNlcXVlbmNlKGp1bXBVcCxqdW1wRG93bixzZXRKdW1wKTtcclxuICAgIH0sXHJcbiAgICBmbHlBY3Rpb24gKCl7XHJcbiAgICAgICAgdmFyIGZseVVwID0gY2MubW92ZUJ5KHRoaXMuZmx5RHVyYXRpb24sIGNjLnYyKDAsdGhpcy5mbHlIZWlnaHQpKS5lYXNpbmcoY2MuZWFzZUN1YmljQWN0aW9uT3V0KCkpXHJcbiAgICAgICAgdmFyIGZseURvd24gPSBjYy5tb3ZlQnkodGhpcy5mbHlEdXJhdGlvbiwgY2MudjIoMCwgLXRoaXMuZmx5SGVpZ2h0KSkuZWFzaW5nKGNjLmVhc2VDdWJpY0FjdGlvbkluKCkpO1xyXG4gICAgICAgIHZhciBzZXRGbHk9Y2MuY2FsbEZ1bmMoZnVuY3Rpb24oKXt0aGlzLmlzRmx5PWZhbHNlfSx0aGlzLHRoaXMpO1xyXG4gICAgICAgIHJldHVybiBjYy5zZXF1ZW5jZShmbHlVcCxmbHlEb3duLHNldEZseSk7XHJcbiAgICAgIH0sXHJcbiAgICBvbktleURvd24gKGV2ZW50KSB7XHJcbiAgICAgICAgc3dpdGNoKGV2ZW50LmtleUNvZGUpIHtcclxuICAgICAgICAgICAgY2FzZSBjYy5tYWNyby5LRVkuYTpcclxuICAgICAgICAgICAgY29uc29sZS5sb2codGhpcy5ub2RlLngpXHJcbiAgICAgICAgICAgICAgICB0aGlzLmFjY0xlZnQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgY2MubWFjcm8uS0VZLmQ6XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFjY1JpZ2h0ID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlIGNjLm1hY3JvLktFWS53OlxyXG4gICAgICAgICAgICAgIGlmKCF0aGlzLmlzSnVtcCl7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmlzSnVtcCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm5vZGUucnVuQWN0aW9uKHRoaXMuanVtcEFjdGlvbigpKTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgY2FzZSBjYy5tYWNyby5LRVkucTpcclxuICAgICAgICAgICAgICAgICAgaWYodGhpcy5pc0ZseSl7XHJcbiAgICAgICAgICAgICAgICAgICAgICB0aGlzLmlzRmx5PXRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICB0aGlzLm5vZGUucnVuQWN0aW9uKHRoaXMuZmx5QWN0aW9uKCkpO1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuXHRvbktleVVwIChldmVudCkge1xyXG4gICAgICAgIHN3aXRjaChldmVudC5rZXlDb2RlKSB7XHJcbiAgICAgICAgICAgIGNhc2UgY2MubWFjcm8uS0VZLmE6XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFjY0xlZnQgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlIGNjLm1hY3JvLktFWS5kOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5hY2NSaWdodCA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7ICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxufSk7Il19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/cherry.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '3002dRgrmZJPondSORGG/k9', 'cherry');
// Script/cherry.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    getRadius: 50
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxjaGVycnkuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJnZXRSYWRpdXMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUNJO0FBQ0ksYUFBUUQsRUFBRSxDQUFDRSxTQURmO0FBRUlDLEVBQUFBLFVBQVUsRUFBQztBQUNQQyxJQUFBQSxTQUFTLEVBQUM7QUFESDtBQUZmLENBREoiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNjLkNsYXNzKFxyXG4gICAge1xyXG4gICAgICAgIGV4dGVuZHM6Y2MuQ29tcG9uZW50LFxyXG4gICAgICAgIHByb3BlcnRpZXM6e1xyXG4gICAgICAgICAgICBnZXRSYWRpdXM6NTAsXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbikiXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/storage.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e5e78suL7tK74pcywzeoVxg', 'storage');
// Script/storage.js

"use strict";

exports.__esModule = true;
exports["default"] = void 0;
var Storage = {
  getHighScore: function getHighScore() {
    var score = cc.sys.localStorage.getItem('HighScore') || 0;
    return parseInt(score);
  },
  setHighScore: function setHighScore(score) {
    cc.sys.localStorage.setItem('HighScore', score);
  }
};
var _default = Storage;
exports["default"] = _default;
module.exports = exports["default"];

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxzdG9yYWdlLmpzIl0sIm5hbWVzIjpbIlN0b3JhZ2UiLCJnZXRIaWdoU2NvcmUiLCJzY29yZSIsImNjIiwic3lzIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsInBhcnNlSW50Iiwic2V0SGlnaFNjb3JlIiwic2V0SXRlbSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUlBLE9BQU8sR0FBRztBQUNWQyxFQUFBQSxZQUFZLEVBQUUsd0JBQVc7QUFDckIsUUFBSUMsS0FBSyxHQUFHQyxFQUFFLENBQUNDLEdBQUgsQ0FBT0MsWUFBUCxDQUFvQkMsT0FBcEIsQ0FBNEIsV0FBNUIsS0FBNEMsQ0FBeEQ7QUFDQSxXQUFPQyxRQUFRLENBQUNMLEtBQUQsQ0FBZjtBQUNILEdBSlM7QUFNVk0sRUFBQUEsWUFBWSxFQUFFLHNCQUFTTixLQUFULEVBQWdCO0FBQzFCQyxJQUFBQSxFQUFFLENBQUNDLEdBQUgsQ0FBT0MsWUFBUCxDQUFvQkksT0FBcEIsQ0FBNEIsV0FBNUIsRUFBeUNQLEtBQXpDO0FBQ0g7QUFSUyxDQUFkO2VBV2VGIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJ2YXIgU3RvcmFnZSA9IHtcclxuICAgIGdldEhpZ2hTY29yZTogZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgdmFyIHNjb3JlID0gY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKCdIaWdoU2NvcmUnKSB8fCAwO1xyXG4gICAgICAgIHJldHVybiBwYXJzZUludChzY29yZSk7XHJcbiAgICB9LFxyXG4gICAgXHJcbiAgICBzZXRIaWdoU2NvcmU6IGZ1bmN0aW9uKHNjb3JlKSB7XHJcbiAgICAgICAgY2Muc3lzLmxvY2FsU3RvcmFnZS5zZXRJdGVtKCdIaWdoU2NvcmUnLCBzY29yZSk7XHJcbiAgICB9XHJcbn07XHJcbiBcclxuZXhwb3J0IGRlZmF1bHQgU3RvcmFnZTsiXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/constant.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'f9308QY7UNCCa1p/WCTbmCH', 'constant');
// Script/constant.js

"use strict";

exports.__esModule = true;
exports["default"] = void 0;
var Constant = cc.Enum({
  // 地板移动时间间隔
  GROUND_MOVE_INTERVAL: 0.01,
  // 单位时间地板移动速度
  GROUND_VX: [-5, -6, -8, -12, -15, -17, -18, -19, -21, -24, -25, -27],
  GEMDURATION: 4,
  isPressed: false,
  // 游戏失败文字
  GAMEOVER_TEXT: 'GAME OVER',
  // 最高分文字
  HIGHSCORE_TEXT: 'HistoryBest: '
});
var _default = Constant;
exports["default"] = _default;
module.exports = exports["default"];

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxjb25zdGFudC5qcyJdLCJuYW1lcyI6WyJDb25zdGFudCIsImNjIiwiRW51bSIsIkdST1VORF9NT1ZFX0lOVEVSVkFMIiwiR1JPVU5EX1ZYIiwiR0VNRFVSQVRJT04iLCJpc1ByZXNzZWQiLCJHQU1FT1ZFUl9URVhUIiwiSElHSFNDT1JFX1RFWFQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFJQSxRQUFRLEdBQUdDLEVBQUUsQ0FBQ0MsSUFBSCxDQUFRO0FBQ25CO0FBQ0FDLEVBQUFBLG9CQUFvQixFQUFFLElBRkg7QUFHbkI7QUFDQUMsRUFBQUEsU0FBUyxFQUFFLENBQUMsQ0FBQyxDQUFGLEVBQUksQ0FBQyxDQUFMLEVBQU8sQ0FBQyxDQUFSLEVBQVUsQ0FBQyxFQUFYLEVBQWMsQ0FBQyxFQUFmLEVBQWtCLENBQUMsRUFBbkIsRUFBc0IsQ0FBQyxFQUF2QixFQUEwQixDQUFDLEVBQTNCLEVBQThCLENBQUMsRUFBL0IsRUFBa0MsQ0FBQyxFQUFuQyxFQUFzQyxDQUFDLEVBQXZDLEVBQTBDLENBQUMsRUFBM0MsQ0FKUTtBQUtuQkMsRUFBQUEsV0FBVyxFQUFDLENBTE87QUFNbkJDLEVBQUFBLFNBQVMsRUFBQyxLQU5TO0FBT25CO0FBQ0FDLEVBQUFBLGFBQWEsRUFBRSxXQVJJO0FBU25CO0FBQ0FDLEVBQUFBLGNBQWMsRUFBRTtBQVZHLENBQVIsQ0FBZjtlQWFlUiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsidmFyIENvbnN0YW50ID0gY2MuRW51bSh7XHJcbiAgICAvLyDlnLDmnb/np7vliqjml7bpl7Tpl7TpmpRcclxuICAgIEdST1VORF9NT1ZFX0lOVEVSVkFMOiAwLjAxLFxyXG4gICAgLy8g5Y2V5L2N5pe26Ze05Zyw5p2/56e75Yqo6YCf5bqmXHJcbiAgICBHUk9VTkRfVlg6IFstNSwtNiwtOCwtMTIsLTE1LC0xNywtMTgsLTE5LC0yMSwtMjQsLTI1LC0yN10sXHJcbiAgICBHRU1EVVJBVElPTjo0LFxyXG4gICAgaXNQcmVzc2VkOmZhbHNlLFxyXG4gICAgLy8g5ri45oiP5aSx6LSl5paH5a2XXHJcbiAgICBHQU1FT1ZFUl9URVhUOiAnR0FNRSBPVkVSJyxcclxuICAgIC8vIOacgOmrmOWIhuaWh+Wtl1xyXG4gICAgSElHSFNDT1JFX1RFWFQ6ICdIaXN0b3J5QmVzdDogJyxcclxufSk7XHJcbiBcclxuZXhwb3J0IGRlZmF1bHQgQ29uc3RhbnQ7Il19
//------QC-SOURCE-SPLIT------
