
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/help.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'c2840TkJnVG+bE7Zp843Jx0', 'help');
// Script/help.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  onload: function onload() {},
  onHelpBtn: function onHelpBtn() {
    cc.director.loadScene('start');
    isPressed = false;
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxoZWxwLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwib25sb2FkIiwib25IZWxwQnRuIiwiZGlyZWN0b3IiLCJsb2FkU2NlbmUiLCJpc1ByZXNzZWQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRSxFQUhQO0FBTUxDLEVBQUFBLE1BQU0sRUFBQyxrQkFBVSxDQUVoQixDQVJJO0FBU0xDLEVBQUFBLFNBQVMsRUFBQyxxQkFBWTtBQUNsQkwsSUFBQUEsRUFBRSxDQUFDTSxRQUFILENBQVlDLFNBQVosQ0FBc0IsT0FBdEI7QUFDQUMsSUFBQUEsU0FBUyxHQUFDLEtBQVY7QUFDSDtBQVpJLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICBcclxuICAgIH0sXHJcbiAgICBvbmxvYWQ6ZnVuY3Rpb24oKXtcclxuICAgICAgICBcclxuICAgIH0sXHJcbiAgICBvbkhlbHBCdG46ZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZSgnc3RhcnQnKTtcclxuICAgICAgICBpc1ByZXNzZWQ9ZmFsc2U7XHJcbiAgICB9LFxyXG5cclxuICAgXHJcbn0pO1xyXG4iXX0=