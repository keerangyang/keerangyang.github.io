
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/gem.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '27c32vklohIJ638+4REc2Y3', 'gem');
// Script/gem.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    getRadius: 50
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxnZW0uanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJnZXRSYWRpdXMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUNJO0FBQ0ksYUFBUUQsRUFBRSxDQUFDRSxTQURmO0FBRUlDLEVBQUFBLFVBQVUsRUFBQztBQUNQQyxJQUFBQSxTQUFTLEVBQUM7QUFESDtBQUZmLENBREoiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNjLkNsYXNzKFxyXG4gICAge1xyXG4gICAgICAgIGV4dGVuZHM6Y2MuQ29tcG9uZW50LFxyXG4gICAgICAgIHByb3BlcnRpZXM6e1xyXG4gICAgICAgICAgICBnZXRSYWRpdXM6NTAsXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbikiXX0=