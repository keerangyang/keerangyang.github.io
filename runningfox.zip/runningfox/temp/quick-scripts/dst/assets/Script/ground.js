
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/ground.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b594dHWKURNF42Y0SDCJYRY', 'ground');
// Script/ground.js

"use strict";

var _Constant = require("Constant");

var Background = cc.Class({
  "extends": cc.Component,
  properties: {
    // 地板节点数组
    groundNode: {
      "default": [],
      type: [cc.Node]
    },
    // 地板图片对象
    groundImg: {
      "default": null,
      type: cc.Sprite
    }
  },
  // use this for initialization
  onLoad: function onLoad() {
    // 获取屏幕尺寸
    this._size = cc.winSize; // 获取地板图片的宽度

    this._width = this.groundImg.spriteFrame.getRect().width; // 启动“地板移动控制”计时器

    this.schedule(this.onGroundMove, _Constant.GROUND_MOVE_INTERVAL);
  },
  onGroundMove: function onGroundMove() {
    this.groundNode[0].x += _Constant.GROUND_VX[7];
    this.groundNode[1].x += _Constant.GROUND_VX[7];

    if (this.groundNode[0].x <= -962) {
      this.groundNode[0].x = 962;
    }

    if (this.groundNode[1].x <= -962) {
      this.groundNode[1].x = 962;
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxncm91bmQuanMiXSwibmFtZXMiOlsiQmFja2dyb3VuZCIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiZ3JvdW5kTm9kZSIsInR5cGUiLCJOb2RlIiwiZ3JvdW5kSW1nIiwiU3ByaXRlIiwib25Mb2FkIiwiX3NpemUiLCJ3aW5TaXplIiwiX3dpZHRoIiwic3ByaXRlRnJhbWUiLCJnZXRSZWN0Iiwid2lkdGgiLCJzY2hlZHVsZSIsIm9uR3JvdW5kTW92ZSIsIkdST1VORF9NT1ZFX0lOVEVSVkFMIiwieCIsIkdST1VORF9WWCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQTs7QUFFQSxJQUFJQSxVQUFVLEdBQUdDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ3RCLGFBQVNELEVBQUUsQ0FBQ0UsU0FEVTtBQUd0QkMsRUFBQUEsVUFBVSxFQUFFO0FBQ1I7QUFDQUMsSUFBQUEsVUFBVSxFQUFFO0FBQ1IsaUJBQVMsRUFERDtBQUVSQyxNQUFBQSxJQUFJLEVBQUUsQ0FBQ0wsRUFBRSxDQUFDTSxJQUFKO0FBRkUsS0FGSjtBQU1SO0FBQ0FDLElBQUFBLFNBQVMsRUFBRTtBQUNQLGlCQUFTLElBREY7QUFFUEYsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNRO0FBRkY7QUFQSCxHQUhVO0FBZ0J0QjtBQUNBQyxFQUFBQSxNQUFNLEVBQUUsa0JBQVk7QUFDaEI7QUFDQSxTQUFLQyxLQUFMLEdBQWFWLEVBQUUsQ0FBQ1csT0FBaEIsQ0FGZ0IsQ0FHaEI7O0FBQ0EsU0FBS0MsTUFBTCxHQUFjLEtBQUtMLFNBQUwsQ0FBZU0sV0FBZixDQUEyQkMsT0FBM0IsR0FBcUNDLEtBQW5ELENBSmdCLENBS2hCOztBQUNBLFNBQUtDLFFBQUwsQ0FBYyxLQUFLQyxZQUFuQixFQUFpQ0MsOEJBQWpDO0FBQ0gsR0F4QnFCO0FBMEJ0QkQsRUFBQUEsWUFBWSxFQUFFLHdCQUFXO0FBRWpCLFNBQUtiLFVBQUwsQ0FBZ0IsQ0FBaEIsRUFBbUJlLENBQW5CLElBQXdCQyxvQkFBVSxDQUFWLENBQXhCO0FBQ0EsU0FBS2hCLFVBQUwsQ0FBZ0IsQ0FBaEIsRUFBbUJlLENBQW5CLElBQXdCQyxvQkFBVSxDQUFWLENBQXhCOztBQUNBLFFBQUksS0FBS2hCLFVBQUwsQ0FBZ0IsQ0FBaEIsRUFBbUJlLENBQW5CLElBQXVCLENBQUMsR0FBNUIsRUFBaUM7QUFDN0IsV0FBS2YsVUFBTCxDQUFnQixDQUFoQixFQUFtQmUsQ0FBbkIsR0FBdUIsR0FBdkI7QUFDSDs7QUFDRCxRQUFJLEtBQUtmLFVBQUwsQ0FBZ0IsQ0FBaEIsRUFBbUJlLENBQW5CLElBQXlCLENBQUMsR0FBOUIsRUFBbUM7QUFDL0IsV0FBS2YsVUFBTCxDQUFnQixDQUFoQixFQUFtQmUsQ0FBbkIsR0FBdUIsR0FBdkI7QUFDSDtBQUdSO0FBdENxQixDQUFULENBQWpCIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJcclxuaW1wb3J0IHsgR1JPVU5EX01PVkVfSU5URVJWQUwsIEdST1VORF9WWCB9IGZyb20gJ0NvbnN0YW50JztcclxuIFxyXG52YXIgQmFja2dyb3VuZCA9IGNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuIFxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIC8vIOWcsOadv+iKgueCueaVsOe7hFxyXG4gICAgICAgIGdyb3VuZE5vZGU6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogW10sXHJcbiAgICAgICAgICAgIHR5cGU6IFtjYy5Ob2RlXVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgLy8g5Zyw5p2/5Zu+54mH5a+56LGhXHJcbiAgICAgICAgZ3JvdW5kSW1nOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLlNwcml0ZVxyXG4gICAgICAgIH0sXHJcbiAgICB9LFxyXG4gXHJcbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cclxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIC8vIOiOt+WPluWxj+W5leWwuuWvuFxyXG4gICAgICAgIHRoaXMuX3NpemUgPSBjYy53aW5TaXplO1xyXG4gICAgICAgIC8vIOiOt+WPluWcsOadv+WbvueJh+eahOWuveW6plxyXG4gICAgICAgIHRoaXMuX3dpZHRoID0gdGhpcy5ncm91bmRJbWcuc3ByaXRlRnJhbWUuZ2V0UmVjdCgpLndpZHRoO1xyXG4gICAgICAgIC8vIOWQr+WKqOKAnOWcsOadv+enu+WKqOaOp+WItuKAneiuoeaXtuWZqFxyXG4gICAgICAgIHRoaXMuc2NoZWR1bGUodGhpcy5vbkdyb3VuZE1vdmUsIEdST1VORF9NT1ZFX0lOVEVSVkFMKTtcclxuICAgIH0sXHJcbiBcclxuICAgIG9uR3JvdW5kTW92ZTogZnVuY3Rpb24oKSB7XHJcbiAgICAgICBcclxuICAgICAgICAgICAgdGhpcy5ncm91bmROb2RlWzBdLnggKz0gR1JPVU5EX1ZYWzddO1xyXG4gICAgICAgICAgICB0aGlzLmdyb3VuZE5vZGVbMV0ueCArPSBHUk9VTkRfVlhbN107XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmdyb3VuZE5vZGVbMF0ueCA8PS05NjIpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuZ3JvdW5kTm9kZVswXS54ID0gOTYyIDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAodGhpcy5ncm91bmROb2RlWzFdLnggIDw9IC05NjIpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuZ3JvdW5kTm9kZVsxXS54ID0gOTYyIDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICBcclxuICAgIH0sXHJcbn0pOyJdfQ==