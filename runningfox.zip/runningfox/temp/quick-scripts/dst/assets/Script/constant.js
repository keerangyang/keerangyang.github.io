
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/constant.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'f9308QY7UNCCa1p/WCTbmCH', 'constant');
// Script/constant.js

"use strict";

exports.__esModule = true;
exports["default"] = void 0;
var Constant = cc.Enum({
  // 地板移动时间间隔
  GROUND_MOVE_INTERVAL: 0.01,
  // 单位时间地板移动速度
  GROUND_VX: [-5, -6, -8, -12, -15, -17, -18, -19, -21, -24, -25, -27],
  GEMDURATION: 4,
  isPressed: false,
  // 游戏失败文字
  GAMEOVER_TEXT: 'GAME OVER',
  // 最高分文字
  HIGHSCORE_TEXT: 'HistoryBest: '
});
var _default = Constant;
exports["default"] = _default;
module.exports = exports["default"];

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxjb25zdGFudC5qcyJdLCJuYW1lcyI6WyJDb25zdGFudCIsImNjIiwiRW51bSIsIkdST1VORF9NT1ZFX0lOVEVSVkFMIiwiR1JPVU5EX1ZYIiwiR0VNRFVSQVRJT04iLCJpc1ByZXNzZWQiLCJHQU1FT1ZFUl9URVhUIiwiSElHSFNDT1JFX1RFWFQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFJQSxRQUFRLEdBQUdDLEVBQUUsQ0FBQ0MsSUFBSCxDQUFRO0FBQ25CO0FBQ0FDLEVBQUFBLG9CQUFvQixFQUFFLElBRkg7QUFHbkI7QUFDQUMsRUFBQUEsU0FBUyxFQUFFLENBQUMsQ0FBQyxDQUFGLEVBQUksQ0FBQyxDQUFMLEVBQU8sQ0FBQyxDQUFSLEVBQVUsQ0FBQyxFQUFYLEVBQWMsQ0FBQyxFQUFmLEVBQWtCLENBQUMsRUFBbkIsRUFBc0IsQ0FBQyxFQUF2QixFQUEwQixDQUFDLEVBQTNCLEVBQThCLENBQUMsRUFBL0IsRUFBa0MsQ0FBQyxFQUFuQyxFQUFzQyxDQUFDLEVBQXZDLEVBQTBDLENBQUMsRUFBM0MsQ0FKUTtBQUtuQkMsRUFBQUEsV0FBVyxFQUFDLENBTE87QUFNbkJDLEVBQUFBLFNBQVMsRUFBQyxLQU5TO0FBT25CO0FBQ0FDLEVBQUFBLGFBQWEsRUFBRSxXQVJJO0FBU25CO0FBQ0FDLEVBQUFBLGNBQWMsRUFBRTtBQVZHLENBQVIsQ0FBZjtlQWFlUiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsidmFyIENvbnN0YW50ID0gY2MuRW51bSh7XHJcbiAgICAvLyDlnLDmnb/np7vliqjml7bpl7Tpl7TpmpRcclxuICAgIEdST1VORF9NT1ZFX0lOVEVSVkFMOiAwLjAxLFxyXG4gICAgLy8g5Y2V5L2N5pe26Ze05Zyw5p2/56e75Yqo6YCf5bqmXHJcbiAgICBHUk9VTkRfVlg6IFstNSwtNiwtOCwtMTIsLTE1LC0xNywtMTgsLTE5LC0yMSwtMjQsLTI1LC0yN10sXHJcbiAgICBHRU1EVVJBVElPTjo0LFxyXG4gICAgaXNQcmVzc2VkOmZhbHNlLFxyXG4gICAgLy8g5ri45oiP5aSx6LSl5paH5a2XXHJcbiAgICBHQU1FT1ZFUl9URVhUOiAnR0FNRSBPVkVSJyxcclxuICAgIC8vIOacgOmrmOWIhuaWh+Wtl1xyXG4gICAgSElHSFNDT1JFX1RFWFQ6ICdIaXN0b3J5QmVzdDogJyxcclxufSk7XHJcbiBcclxuZXhwb3J0IGRlZmF1bHQgQ29uc3RhbnQ7Il19