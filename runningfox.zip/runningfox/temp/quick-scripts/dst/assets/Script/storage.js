
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/storage.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e5e78suL7tK74pcywzeoVxg', 'storage');
// Script/storage.js

"use strict";

exports.__esModule = true;
exports["default"] = void 0;
var Storage = {
  getHighScore: function getHighScore() {
    var score = cc.sys.localStorage.getItem('HighScore') || 0;
    return parseInt(score);
  },
  setHighScore: function setHighScore(score) {
    cc.sys.localStorage.setItem('HighScore', score);
  }
};
var _default = Storage;
exports["default"] = _default;
module.exports = exports["default"];

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxzdG9yYWdlLmpzIl0sIm5hbWVzIjpbIlN0b3JhZ2UiLCJnZXRIaWdoU2NvcmUiLCJzY29yZSIsImNjIiwic3lzIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsInBhcnNlSW50Iiwic2V0SGlnaFNjb3JlIiwic2V0SXRlbSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUlBLE9BQU8sR0FBRztBQUNWQyxFQUFBQSxZQUFZLEVBQUUsd0JBQVc7QUFDckIsUUFBSUMsS0FBSyxHQUFHQyxFQUFFLENBQUNDLEdBQUgsQ0FBT0MsWUFBUCxDQUFvQkMsT0FBcEIsQ0FBNEIsV0FBNUIsS0FBNEMsQ0FBeEQ7QUFDQSxXQUFPQyxRQUFRLENBQUNMLEtBQUQsQ0FBZjtBQUNILEdBSlM7QUFNVk0sRUFBQUEsWUFBWSxFQUFFLHNCQUFTTixLQUFULEVBQWdCO0FBQzFCQyxJQUFBQSxFQUFFLENBQUNDLEdBQUgsQ0FBT0MsWUFBUCxDQUFvQkksT0FBcEIsQ0FBNEIsV0FBNUIsRUFBeUNQLEtBQXpDO0FBQ0g7QUFSUyxDQUFkO2VBV2VGIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJ2YXIgU3RvcmFnZSA9IHtcclxuICAgIGdldEhpZ2hTY29yZTogZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgdmFyIHNjb3JlID0gY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKCdIaWdoU2NvcmUnKSB8fCAwO1xyXG4gICAgICAgIHJldHVybiBwYXJzZUludChzY29yZSk7XHJcbiAgICB9LFxyXG4gICAgXHJcbiAgICBzZXRIaWdoU2NvcmU6IGZ1bmN0aW9uKHNjb3JlKSB7XHJcbiAgICAgICAgY2Muc3lzLmxvY2FsU3RvcmFnZS5zZXRJdGVtKCdIaWdoU2NvcmUnLCBzY29yZSk7XHJcbiAgICB9XHJcbn07XHJcbiBcclxuZXhwb3J0IGRlZmF1bHQgU3RvcmFnZTsiXX0=