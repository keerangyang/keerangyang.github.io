import player from 'player';
import { GROUND_MOVE_INTERVAL,GAMEOVER_TEXT,GROUND_VX,GEMDURATION,HIGHSCORE_TEXT,isPressed } from 'Constant'; 

var storage=require('storage');
cc.Class({
    extends: cc.Component,
 
    properties: {
        gameReflashTime:5,
        scoreScaleDuration:0.2,
        rockPrefabs: {
            default: [],
            type: [cc.Prefab]
        },
        rockNode: { 
            default: null,
            
            type: cc.Node
        },
        gemPrefabs:{
            default:[],
            type:[cc.Prefab]
        },
        gemNode:{
            default:null,
            type:cc.Node
        },
        cherryPrefabs:{
            default:[],
            type:[cc.Prefab]
        },
        cherryNode:{
            default:null,
            type:cc.Node
        },
      player:{
          default:null,
          type:player
      },
     
      gameOverText:{
          default:null,
          type:cc.Label
      },
      scoreText:{
          default:null,
          type:cc.Label
      },
      highsScoreText:{
          default:null,
          type:cc.Label
      },
      livesScoreText:{
          default:null,
          type:cc.Label
      }
    },

 onLoad:function(){

  
     this.rock=[];
     this.gem=[];
     this.cherry=[];
     this.curScore=0;
     this.curLife=0;
     this.gemTimer=0;
     this.cherryTimer=0;
     if(storage.getHighScore()>0){
         this.highsScoreText.string=HIGHSCORE_TEXT+storage.getHighScore();
     }
    this.schedule(this.spawnRock,4.5);
    this.schedule(this.spawnGem,4.5);
    this.schedule(this.spawnCherry,4.5);
    this.schedule(this.gameUpdate,GROUND_MOVE_INTERVAL);
    this.scoreText.string=""+this.curScore;
    this.livesScoreText.string=""+this.curLife;
 },
    menuBtn:function(){
    cc.director.loadScene('start');
    },
    spawnCherry:function(){
        var cherry =cc.instantiate(this.cherryPrefabs[0]);
        cherry.x=(Math.random() - 0.5) * 2*this.node.width/2;
        cherry.y=0;
        this.cherryNode.addChild(cherry);
        this.cherry.push(cherry);
    },
    spawnRock:function(){
    var rock=cc.instantiate(this.rockPrefabs[0]);
    rock.x=400;
    rock.y=-80;
    this.rockNode.addChild(rock);
    this.rock.push(rock);
    },
    spawnGem:function(){
        var gem=cc.instantiate(this.gemPrefabs[0]);
        gem.x=(Math.random() - 0.5) * 2*this.node.width/2;
        gem.y=250;
        this.gemNode.addChild(gem);
        this.gem.push(gem);
    },
   gameUpdate:function(dt){
     for(var i=0;i<this.rock.length;i++){
         var curNode=this.rock[i];
         if(i>=12){
             curNode.x+=GROUND_VX[11]-i%10;
         }
         else{
            curNode.x+=GROUND_VX[i%12];
         }
         var playerBox=this.player.node.getBoundingBox();
         var rockBox=curNode.getBoundingBox();
         var curRock=curNode.getComponent('rock');
         if(cc.Intersection.rectRect(playerBox,rockBox)&&curRock.isPassed===false){
             curRock.isPassed=true;
             this.subLife();
             if(this.curLife<0){
                this.onGameOver();
                return;
             }
         }
        
         if(curNode.x<this.player.node.x&&curRock.isPassed===false){
             curRock.isPassed=true;
             this.addScore();
            
         }
     }
     for(var i=0;i<this.gem.length;i++){
       
        var curGemNode=this.gem[i];
         this.gemTimer+=dt;
         if(this.gemTimer>GEMDURATION){
             this.gem.splice(i,1);
             this.gemNode.removeChild(curGemNode,true);
             this.gemTimer=0;
         }
         var playerPos=this.player.node.getPosition();
         var gemPos=curGemNode.getPosition();
         var temp=playerPos.sub(gemPos);
         var dist=Math.abs(temp.mag());
         var curGem=curGemNode.getComponent('gem');
        if(dist<curGem.getRadius){
            this.gem.splice(i,1);
            this.gemNode.removeChild(curGemNode,true);
            this.addLife();
            
        }
       
     }
     for(var i=0;i<this.cherry.length;i++){
        this.player.isFly=false; 
        var curCherryNode=this.cherry[i];
         this.cherryTimer+=dt;
         if(this.cherryTimer>GEMDURATION){
             this.cherry.splice(i,1);
             this.cherryNode.removeChild(curCherryNode,true);
             this.cherryTimer=0;
         }
         var playerPos=this.player.node.getPosition();
         var cherryPos=curCherryNode.getPosition();
         var temp=playerPos.sub(cherryPos);
         var dist=Math.abs(temp.mag());
         var curCherry=curCherryNode.getComponent('cherry');
        if(dist<curCherry.getRadius){
            this.cherry.splice(i,1);
            this.cherryNode.removeChild(curCherryNode,true);
            this.player.isFly=true;
        }
       
     }
   },
   addScore:function(){
       this.curScore++;
       this.scoreText.string=""+this.curScore;
       var action1=cc.scaleTo(this.scoreScaleDuration,1.1,0.6);
       var action2=cc.scaleTo(this.scoreScaleDuration,0.8,1.2);
       var action3=cc.scaleTo(this.scoreScaleDuration,1,1);
       this.scoreText.node.runAction(cc.sequence(action1,action2,action3));
   },
   addLife:function(){
       this.curLife++;
       this.livesScoreText.string=""+this.curLife;
       var action1=cc.scaleTo(this.scoreScaleDuration,1.1,0.6);
       var action2=cc.scaleTo(this.scoreScaleDuration,0.8,1.2);
       var action3=cc.scaleTo(this.scoreScaleDuration,1,1);
       this.livesScoreText.node.runAction(cc.sequence(action1,action2,action3));
     },
    subLife:function(){
        this.curLife--;
        this.livesScoreText.string=""+this.curLife;
        var action1=cc.scaleTo(this.scoreScaleDuration,1.1,0.6);
        var action2=cc.scaleTo(this.scoreScaleDuration,0.8,1.2);
        var action3=cc.scaleTo(this.scoreScaleDuration,1,1);
        this.livesScoreText.node.runAction(cc.sequence(action1,action2,action3));
    },
   onGameOver:function(){
       this.gameOverText.string=GAMEOVER_TEXT;
       if(this.curScore>storage.getHighScore()){
           storage.setHighScore(this.curScore);
       }
        this.unscheduleAllCallbacks();
        this.schedule(function() {
            cc.director.loadScene('start');
        }, this.gameReflashTime);
   }
});