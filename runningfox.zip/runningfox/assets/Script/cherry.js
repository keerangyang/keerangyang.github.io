cc.Class(
    {
        extends:cc.Component,
        properties:{
            getRadius:50,
        }
    },

)