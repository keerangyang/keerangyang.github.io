var Constant = cc.Enum({
    // 地板移动时间间隔
    GROUND_MOVE_INTERVAL: 0.01,
    // 单位时间地板移动速度
    GROUND_VX: [-5,-6,-8,-12,-15,-17,-18,-19,-21,-24,-25,-27],
    GEMDURATION:4,
    isPressed:false,
    // 游戏失败文字
    GAMEOVER_TEXT: 'GAME OVER',
    // 最高分文字
    HIGHSCORE_TEXT: 'HistoryBest: ',
});
 
export default Constant;