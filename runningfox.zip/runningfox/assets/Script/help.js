

cc.Class({
    extends: cc.Component,

    properties: {
     
    },
    onload:function(){
        
    },
    onHelpBtn:function () {
        cc.director.loadScene('start');
        isPressed=false;
    },

   
});
