
import { GROUND_MOVE_INTERVAL, GROUND_VX } from 'Constant';
 
var Background = cc.Class({
    extends: cc.Component,
 
    properties: {
        // 地板节点数组
        groundNode: {
            default: [],
            type: [cc.Node]
        },
        // 地板图片对象
        groundImg: {
            default: null,
            type: cc.Sprite
        },
    },
 
    // use this for initialization
    onLoad: function () {
        // 获取屏幕尺寸
        this._size = cc.winSize;
        // 获取地板图片的宽度
        this._width = this.groundImg.spriteFrame.getRect().width;
        // 启动“地板移动控制”计时器
        this.schedule(this.onGroundMove, GROUND_MOVE_INTERVAL);
    },
 
    onGroundMove: function() {
       
            this.groundNode[0].x += GROUND_VX[7];
            this.groundNode[1].x += GROUND_VX[7];
            if (this.groundNode[0].x <=-962) {
                this.groundNode[0].x = 962 ;
            }
            if (this.groundNode[1].x  <= -962) {
                this.groundNode[1].x = 962 ;
            }
        
      
    },
});