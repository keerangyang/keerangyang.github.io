"use strict";
cc._RF.push(module, '27c32vklohIJ638+4REc2Y3', 'gem');
// Script/gem.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    getRadius: 50
  }
});

cc._RF.pop();