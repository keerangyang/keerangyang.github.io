"use strict";
cc._RF.push(module, 'e5e78suL7tK74pcywzeoVxg', 'storage');
// Script/storage.js

"use strict";

exports.__esModule = true;
exports["default"] = void 0;
var Storage = {
  getHighScore: function getHighScore() {
    var score = cc.sys.localStorage.getItem('HighScore') || 0;
    return parseInt(score);
  },
  setHighScore: function setHighScore(score) {
    cc.sys.localStorage.setItem('HighScore', score);
  }
};
var _default = Storage;
exports["default"] = _default;
module.exports = exports["default"];

cc._RF.pop();