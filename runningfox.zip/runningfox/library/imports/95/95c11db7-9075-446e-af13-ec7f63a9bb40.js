"use strict";
cc._RF.push(module, '95c1123kHVEbq8T7H9jqbtA', 'rock');
// Script/rock.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    // 小鸟通过管道与否的标志位
    isPassed: false
  },
  // use this for initialization
  onLoad: function onLoad() {},
  init: function init(type) {
    // 设置管道的类型（上或下）
    this.type = type;
  } // called every frame, uncomment this function to activate update callback
  // update: function (dt) {
  // },

});

cc._RF.pop();