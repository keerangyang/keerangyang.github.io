"use strict";
cc._RF.push(module, '70b81/DQRFKPpV1hbZ91sa6', 'start');
// Script/start.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {},
  start: function start() {},
  onLoad: function onLoad() {},
  startBtn: function startBtn() {
    cc.director.loadScene('game');
  },
  helpBtn: function helpBtn() {
    cc.director.loadScene('help');
  }
});

cc._RF.pop();