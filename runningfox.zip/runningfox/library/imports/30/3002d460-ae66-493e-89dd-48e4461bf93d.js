"use strict";
cc._RF.push(module, '3002dRgrmZJPondSORGG/k9', 'cherry');
// Script/cherry.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    getRadius: 50
  }
});

cc._RF.pop();