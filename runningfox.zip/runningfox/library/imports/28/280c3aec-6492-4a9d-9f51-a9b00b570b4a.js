"use strict";
cc._RF.push(module, '280c3rsZJJKnZ9RqbALVwtK', 'player');
// Script/player.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    jumpHeight: 200,
    jumpDuration: 0.35,
    flyHeight: 250,
    flyDuration: 2,
    xSpeed: 350,
    AnimName: 'fox'
  },
  onLoad: function onLoad() {
    this.getComponent(cc.Animation).play(this.AnimName); // 初始化键盘输入监听

    cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
    cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, this.onKeyUp, this);
  },
  start: function start() {},
  update: function update(dt) {
    //根据当前速度方向每帧更新速度
    if (this.accLeft) {
      this.node.x -= this.xSpeed * dt;
    } else if (this.accRight) {
      this.node.x += this.xSpeed * dt;
    }
  },
  onDestroy: function onDestroy() {
    // 取消键盘输入监听
    cc.systemEvent.off(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
    cc.systemEvent.off(cc.SystemEvent.EventType.KEY_UP, this.onKeyUp, this);
  },
  //跳跃功能，在跳跃期间暂停跳跃功能
  jumpAction: function jumpAction() {
    var jumpUp = cc.moveBy(this.jumpDuration, cc.v2(0, this.jumpHeight)).easing(cc.easeCubicActionOut());
    var jumpDown = cc.moveBy(this.jumpDuration, cc.v2(0, -this.jumpHeight)).easing(cc.easeCubicActionIn());
    var setJump = cc.callFunc(function () {
      this.isJump = false;
    }, this, this);
    return cc.sequence(jumpUp, jumpDown, setJump);
  },
  flyAction: function flyAction() {
    var flyUp = cc.moveBy(this.flyDuration, cc.v2(0, this.flyHeight)).easing(cc.easeCubicActionOut());
    var flyDown = cc.moveBy(this.flyDuration, cc.v2(0, -this.flyHeight)).easing(cc.easeCubicActionIn());
    var setFly = cc.callFunc(function () {
      this.isFly = false;
    }, this, this);
    return cc.sequence(flyUp, flyDown, setFly);
  },
  onKeyDown: function onKeyDown(event) {
    switch (event.keyCode) {
      case cc.macro.KEY.a:
        console.log(this.node.x);
        this.accLeft = true;
        break;

      case cc.macro.KEY.d:
        this.accRight = true;
        break;

      case cc.macro.KEY.w:
        if (!this.isJump) {
          this.isJump = true;
          this.node.runAction(this.jumpAction());
        }

        break;

      case cc.macro.KEY.q:
        if (this.isFly) {
          this.isFly = true;
          this.node.runAction(this.flyAction());
        }

        break;
    }
  },
  onKeyUp: function onKeyUp(event) {
    switch (event.keyCode) {
      case cc.macro.KEY.a:
        this.accLeft = false;
        break;

      case cc.macro.KEY.d:
        this.accRight = false;
        break;
    }
  }
});

cc._RF.pop();