"use strict";
cc._RF.push(module, 'c2840TkJnVG+bE7Zp843Jx0', 'help');
// Script/help.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  onload: function onload() {},
  onHelpBtn: function onHelpBtn() {
    cc.director.loadScene('start');
    isPressed = false;
  }
});

cc._RF.pop();